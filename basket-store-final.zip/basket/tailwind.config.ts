import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: "#070d1a",
          900: "#0c1424",
          800: "#14203a",
          700: "#1d2d50",
        },
        accent: {
          400: "#5b8def",
          500: "#2f6bea",
          600: "#1f56cf",
        },
        paper: "#f6f7f9",
      },
      boxShadow: {
        card: "0 1px 2px rgba(12, 20, 36, 0.05), 0 10px 30px -14px rgba(12, 20, 36, 0.16)",
        cardHover: "0 2px 4px rgba(12, 20, 36, 0.06), 0 22px 44px -18px rgba(12, 20, 36, 0.28)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-sora)", "var(--font-inter)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
