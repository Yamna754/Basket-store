# BASKET — Racing Jacket E-Commerce Store

A complete, modular Next.js 14 (App Router) + TypeScript + Tailwind CSS storefront, built for BASKET's racing-inspired jacket line. Runs today on local demo data (no backend required) and is architected to drop in Supabase for products, orders and admin auth without rewriting any UI.

---

## 1. Folder Structure

```
basket/
├── app/                        # Next.js App Router — one folder per route
│   ├── page.tsx                # Home
│   ├── layout.tsx              # Root layout (Header/Footer/CartProvider, SEO metadata)
│   ├── globals.css             # Tailwind entry + small global styles
│   ├── sitemap.ts / robots.ts  # Generated SEO files
│   ├── products/
│   │   ├── page.tsx            # Products listing (search + category filter)
│   │   └── [slug]/page.tsx     # Product details page
│   ├── order/page.tsx          # Order form page
│   ├── contact/page.tsx        # Contact Us page
│   ├── admin/
│   │   ├── page.tsx            # Admin login
│   │   └── dashboard/page.tsx  # Admin dashboard (orders table)
│   └── api/
│       ├── orders/route.ts         # GET all orders, POST new order
│       ├── orders/[id]/route.ts    # PATCH order status
│       ├── contact/route.ts        # POST contact message
│       └── chat/route.ts           # Stub for future AI chatbot
│
├── components/                 # Reusable, presentational + interactive UI
│   ├── ui/                     # Button, Card, Input, Modal, Table, Badge
│   ├── Header.tsx, Footer.tsx, Hero.tsx
│   ├── ProductCard.tsx, ProductGrid.tsx, ProductsFilterBar.tsx
│   ├── ProductDetails.tsx      # Interactive gallery/color/size/qty
│   ├── OrderForm.tsx, OrderSummary.tsx
│   ├── AdminTable.tsx, AdminLoginForm.tsx
│   ├── WhatsAppButton.tsx      # Every WhatsApp CTA goes through here
│   └── chatbot/                # Empty folder reserved for the future chat widget
│
├── context/CartContext.tsx     # Cart state (React Context + sessionStorage)
│
├── lib/                        # Business logic, kept out of components
│   ├── config.ts               # ⭐ Store name, WhatsApp #, contact info, hero copy
│   ├── products.ts             # Product data-access layer (swap for Supabase here)
│   ├── orders.ts                # Order data-access layer + server-side validation
│   ├── auth.ts                  # Demo admin login check
│   ├── utils.ts                 # formatPrice, WhatsApp link builder, etc.
│   ├── data/                    # Raw demo records (products.data.ts, categories.data.ts)
│   ├── supabase/                # client.ts (browser), server.ts (service-role), products.ts, orders.ts
│   ├── payments/index.ts        # Payment-method abstraction (COD wired, others stubbed)
│   └── chatbot/index.ts         # Chatbot logic stub
│
├── types/                       # Product, Order, Customer, Admin, Category, Settings
├── public/images/                # Logo + product photos (see section 4)
├── supabase/schema.sql           # Full Postgres schema + RLS policies
├── middleware.ts                 # Demo admin-route protection
├── .env.example                  # Copy to .env.local and fill in
└── tailwind.config.ts / next.config.js / tsconfig.json
```

**Design rule this project follows:** components never import mock data or Supabase directly — everything goes through `lib/products.ts` / `lib/orders.ts`. That's the seam where demo mode becomes production mode.

---

## 2. Running It Locally

Requires Node.js 18.18+ (Node 20 recommended).

```bash
cd basket
npm install
cp .env.example .env.local     # defaults already work in demo mode
npm run dev
```

Open **http://localhost:3000**.

Admin dashboard: go to **/admin**, log in with the demo credentials shown on that page (`admin@basket-store.com` / `basket-demo-2026`, also visible in `lib/auth.ts`).

To build for production: `npm run build && npm start`.

---

## 3. Adding or Changing Products

Products are **not** hard-coded into any page or component. Open:

```
lib/data/products.data.ts
```

and add a new object to the `PRODUCTS` array:

```ts
{
  id: "4",
  slug: "your-product-slug",
  name: "Your Product Name",
  shortDescription: "One-line summary shown on the card.",
  description: "Longer paragraph shown on the product page.",
  price: 5999,
  compareAtPrice: 6999,          // optional — omit if not on sale
  images: [{ url: "/images/your-photo.jpg", alt: "Your Product Name" }],
  category: "racing-jackets",     // must match a slug in categories.data.ts
  colors: [{ name: "Black", hex: "#0f0f0f" }],
  sizes: ["S", "M", "L", "XL"],
  stock: 20,
  featured: true,                 // true = shows in the homepage "Featured" section
  active: true,                   // false = hidden everywhere without deleting it
  createdAt: "2026-01-01T00:00:00.000Z",
  updatedAt: "2026-01-01T00:00:00.000Z",
},
```

It will automatically appear on the Home page (if `featured: true`), the Products page, get its own `/products/your-product-slug` detail page, show up in search/filtering, and appear as an option in the Order Form's product dropdown. Nothing else needs to change.

To add a new **category**, add it to `lib/data/categories.data.ts`.

---

## 4. Changing Prices

Prices live on each product object in `lib/data/products.data.ts` — edit `price` (and `compareAtPrice` for a strikethrough sale price) directly. No other file references prices; `formatPrice()` in `lib/utils.ts` handles all display formatting and currency symbol (`Rs.` by default — change `currencySymbol`/`currency` in `lib/config.ts`).

---

## 5. Changing the WhatsApp Number

Edit **one** value in `.env.local`:

```
NEXT_PUBLIC_WHATSAPP_NUMBER=923001234567
```

(Country code + number, no `+`, no spaces/dashes.) Every "Order on WhatsApp" / "Chat on WhatsApp" button in the app reads from this single variable via `lib/config.ts` → `lib/utils.ts#buildWhatsAppLink` — there is no other place the number is written.

---

## 6. Changing Email / Phone / Address

All in `.env.local`:

```
NEXT_PUBLIC_CONTACT_EMAIL=hello@basket-store.com
NEXT_PUBLIC_CONTACT_PHONE=+92 300 1234567
NEXT_PUBLIC_CONTACT_ADDRESS=Shop 12, Fashion Plaza, Karachi, Pakistan
```

These flow into `lib/config.ts` → `SITE_SETTINGS`, which powers the Footer and the Contact page. (You can also hard-edit the fallback values directly in `lib/config.ts` if you'd rather not use env vars.)

---

## 7. Connecting Supabase (going from Demo → Production)

1. **Create a Supabase project** at supabase.com.
2. **Run the schema**: open the SQL Editor in your Supabase project and run the contents of `supabase/schema.sql`. This creates `products`, `categories`, `orders`, `order_items`, `customers`, `addresses`, `payments`, `coupons`, `reviews`, `admins`, and `site_settings`, plus Row Level Security policies.
3. **Set environment variables** in `.env.local`:
   ```
   NEXT_PUBLIC_APP_MODE=production
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key   # server-only, never exposed to the browser
   ```
4. **Seed products**: insert rows into the `products` table (matching the shape in `types/product.ts`), or write a one-off script using `lib/supabase/server.ts`.
5. **Swap the data layer**: in `lib/products.ts` and `lib/orders.ts`, replace the demo-array logic in each function with a call to the matching function in `lib/supabase/products.ts` / `lib/supabase/orders.ts` (already written and ready — see the comments in those files for the exact one-line swap).
6. **Admin auth**: replace the demo check in `lib/auth.ts` and the cookie check in `middleware.ts` with real Supabase Auth (`supabase.auth.signInWithPassword`, then verify the session server-side). Use the `admins` table to store roles.

No component in `app/` or `components/` needs to change for any of this — they only ever call into `lib/products.ts` / `lib/orders.ts`.

---

## 8. Deploying the Website

Easiest path is **Vercel** (made by the creators of Next.js):

1. Push this project to a GitHub repo.
2. Go to vercel.com → New Project → import the repo.
3. Add your `.env.local` variables under Project Settings → Environment Variables.
4. Deploy. Vercel auto-detects Next.js and builds/runs it correctly.

Other hosts that work: Netlify, Railway, or any Node host (`npm run build && npm start`), as long as environment variables are configured the same way.

---

## 9. Connecting a Custom Domain

On Vercel: Project → Settings → Domains → Add your domain (e.g. `basket-store.com`) → follow the DNS instructions shown (usually one `A` record or `CNAME` at your domain registrar, e.g. GoDaddy/Namecheap). Propagation typically takes a few minutes to a few hours. Once verified, update `NEXT_PUBLIC_SITE_URL` in your environment variables to the new domain for correct SEO metadata.

---

## 10. Demo-Only vs. Production-Ready Features

| Feature | Status | Notes |
|---|---|---|
| Product catalog, search, filtering | ✅ Production-ready | Just needs Supabase data instead of the mock array |
| Product detail page, cart, order form | ✅ Production-ready | Fully functional UI logic |
| Order storage | ⚠️ Demo-only | In-memory on the server (resets on restart) — swap in `lib/orders.ts` per section 7 |
| WhatsApp order/chat buttons | ✅ Production-ready | Just set your real number in `.env.local` |
| Contact form | ⚠️ Demo-only | Currently logs to the server console — wire up email sending (e.g. Resend/SendGrid) or a Supabase table in `app/api/contact/route.ts` |
| Admin login | ❌ **Not secure — demo only** | Hard-coded password + plain cookie, see loud warnings in `lib/auth.ts` and `middleware.ts`. Replace with Supabase Auth before going live |
| Admin dashboard (search/filter/status/export CSV) | ✅ UI production-ready | Works fully once real order data flows through Supabase |
| Payments | ⚠️ Cash on Delivery only | `lib/payments/` is ready for Bank Transfer / card gateways — see comments in that file |
| Chatbot | ❌ Not built | Folder structure only (`components/chatbot/`, `lib/chatbot/`, `app/api/chat/`) — ready to wire up to an AI API later |
| Customer accounts/login | ❌ Not built | `types/customer.ts` and the `customers`/`addresses` tables in the schema are ready for this |
| Coupons, reviews, inventory alerts, wishlist | ❌ Not built | Database tables exist in `supabase/schema.sql`; UI not yet built |

---

## Product Images

Real product photos were not available when this project was generated, so `public/images/` currently contains simple placeholder graphics (labelled "RED BULL", "MONSTER", "FERRARI") standing in for the three jackets, plus a placeholder wordmark logo.

**To use your real images:** save your files into `/public/images/` (any name you like, e.g. `redbull-jacket-1.jpg`), then update the matching product's `images` array in `lib/data/products.data.ts` to point at that filename, e.g. `images: [{ url: "/images/redbull-jacket-1.jpg", alt: "Red Bull Racing Jacket" }]`. Do the same for `public/images/logo.png` (the Header/Footer both reference this exact filename) and `public/images/hero-fashion.jpg` (the homepage hero banner).

**Legal note:** some jacket designs reference third-party racing brands (Red Bull, Monster Energy, Ferrari) for stylistic inspiration. The Footer includes a disclaimer that BASKET is an independent store not affiliated with those brands — keep or adapt that wording, and use properly licensed imagery for any brand-referencing designs before selling publicly.
