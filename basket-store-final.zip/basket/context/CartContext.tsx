"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Product } from "@/types/product";
import { calculateOrderTotals } from "@/lib/utils";

export interface CartLine {
  product: Product;
  color: string;
  size: string;
  quantity: number;
}

interface CartContextValue {
  lines: CartLine[];
  addToCart: (line: CartLine) => void;
  removeFromCart: (index: number) => void;
  updateQuantity: (index: number, quantity: number) => void;
  clearCart: () => void;
  subtotal: number;
  discountAmount: number;
  discountApplied: boolean;
  total: number;
  itemCount: number;
}

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "basket_cart_v1";

/** Wrap the app in <CartProvider> once (see app/layout.tsx). Any client
 * component can then call useCart() to read or modify the cart —
 * this is the only place cart state lives. */
export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // Load from sessionStorage once, on mount (browser only).
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (raw) setLines(JSON.parse(raw));
    } catch {
      // ignore corrupted storage
    } finally {
      setHydrated(true);
    }
  }, []);

  // Persist every change for the duration of the browsing session.
  useEffect(() => {
    if (!hydrated) return;
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      // storage may be unavailable (private browsing) — fail silently
    }
  }, [lines, hydrated]);

  const addToCart = useCallback((line: CartLine) => {
    setLines((prev) => {
      const existingIndex = prev.findIndex(
        (l) => l.product.id === line.product.id && l.color === line.color && l.size === line.size
      );
      if (existingIndex >= 0) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + line.quantity,
        };
        return next;
      }
      return [...prev, line];
    });
  }, []);

  const removeFromCart = useCallback((index: number) => {
    setLines((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const updateQuantity = useCallback((index: number, quantity: number) => {
    setLines((prev) =>
      prev.map((l, i) => (i === index ? { ...l, quantity: Math.max(1, quantity) } : l))
    );
  }, []);

  const clearCart = useCallback(() => setLines([]), []);

  // Single source of truth for pricing, including the "buy 2+ get 10% off"
  // rule — the order form and order summary just read these values.
  const totals = useMemo(
    () =>
      calculateOrderTotals(
        lines.map((l) => ({ quantity: l.quantity, unitPrice: l.product.price }))
      ),
    [lines]
  );

  const value: CartContextValue = {
    lines,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    subtotal: totals.subtotal,
    discountAmount: totals.discountAmount,
    discountApplied: totals.discountApplied,
    total: totals.total,
    itemCount: totals.itemCount,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within <CartProvider>");
  return ctx;
}
