-- ============================================================
-- BASKET — Supabase schema
-- ------------------------------------------------------------
-- Run this in the Supabase SQL editor (Project > SQL Editor > New query)
-- for a new project. It creates the core tables the app is designed
-- to grow into, plus Row Level Security policies so the anon key can
-- only read what it should.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- categories ----------
create table if not exists categories (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  label text not null,
  description text
);

-- ---------- products ----------
create table if not exists products (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  name text not null,
  description text not null,
  short_description text not null,
  price numeric(10, 2) not null,
  compare_at_price numeric(10, 2),
  images jsonb not null default '[]',
  category text references categories(slug),
  colors jsonb not null default '[]',
  sizes jsonb not null default '[]',
  stock int not null default 0,
  featured boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- customers (future: customer accounts) ----------
create table if not exists customers (
  id uuid primary key default uuid_generate_v4(),
  full_name text not null,
  email text unique,
  phone text,
  whatsapp text,
  created_at timestamptz not null default now()
);

create table if not exists addresses (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid references customers(id) on delete cascade,
  label text,
  address text not null,
  city text not null,
  is_default boolean not null default false
);

-- ---------- orders ----------
create table if not exists orders (
  id uuid primary key default uuid_generate_v4(),
  order_number text unique not null,
  customer jsonb not null, -- { fullName, phone, whatsapp, address, city }
  items jsonb not null,    -- array of { productId, productName, color, size, quantity, unitPrice }
  notes text,
  total numeric(10, 2) not null,
  status text not null default 'new'
    check (status in ('new','confirmed','processing','shipped','delivered','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- order_items (normalized alternative to orders.items jsonb) ----------
create table if not exists order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  color text,
  size text,
  quantity int not null,
  unit_price numeric(10, 2) not null
);

-- ---------- payments (future: online payments) ----------
create table if not exists payments (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade,
  method text not null,
  reference text,
  amount numeric(10, 2) not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

-- ---------- coupons (future) ----------
create table if not exists coupons (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  discount_percent numeric(5, 2),
  discount_amount numeric(10, 2),
  active boolean not null default true,
  expires_at timestamptz
);

-- ---------- reviews (future) ----------
create table if not exists reviews (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  customer_id uuid references customers(id),
  rating int check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

-- ---------- admins ----------
-- Prefer Supabase Auth (auth.users) for real admin login; this table
-- stores the extra profile info (role) alongside an auth.users id.
create table if not exists admins (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  role text not null default 'manager' check (role in ('owner','manager','support'))
);

-- ---------- site_settings (future: editable from an admin panel) ----------
create table if not exists site_settings (
  key text primary key,
  value jsonb not null
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ------------------------------------------------------------
-- Public (anon key) can read products/categories, but cannot write
-- anything. Orders/contact messages are inserted through server-side
-- code using the service-role key (see lib/supabase/server.ts), which
-- bypasses RLS — so the browser never needs write access to `orders`.
-- ============================================================

alter table products enable row level security;
alter table categories enable row level security;
alter table orders enable row level security;

create policy "Public can read active products"
  on products for select
  using (active = true);

create policy "Public can read categories"
  on categories for select
  using (true);

-- No public policies on `orders` — all order reads/writes for the
-- admin dashboard go through server-side code with the service-role key.
