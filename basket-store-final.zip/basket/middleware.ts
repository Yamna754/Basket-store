import { NextRequest, NextResponse } from "next/server";

// DEMO-ONLY admin route protection: checks for a plain cookie set on
// login (see components/AdminLoginForm.tsx). This stops casual access
// but is NOT secure — a user can set the cookie themselves in devtools.
//
// PRODUCTION: replace this with a real session check, e.g. reading and
// verifying a Supabase Auth session/JWT. See the README section
// "Connecting Supabase" for the exact steps.
export function middleware(request: NextRequest) {
  const isLoggedIn = request.cookies.get("basket_admin")?.value === "1";

  if (request.nextUrl.pathname.startsWith("/admin/dashboard") && !isLoggedIn) {
    return NextResponse.redirect(new URL("/admin", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/dashboard/:path*"],
};
