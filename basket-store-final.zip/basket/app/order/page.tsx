import type { Metadata } from "next";
import { Suspense } from "react";
import { getAllProducts } from "@/lib/products";
import { OrderForm } from "@/components/OrderForm";

export const metadata: Metadata = {
  title: "Place an Order",
  description: "Select your products, fill in your details, and submit your order.",
};

export default async function OrderPage() {
  const products = await getAllProducts();

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8 md:py-14">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl font-bold text-navy-900 md:text-4xl">Place an Order</h1>
        <p className="mt-2 text-slate-500">
          Fill in your details below and we'll confirm your order on WhatsApp.
        </p>
      </div>
      <Suspense fallback={<p className="text-slate-500">Loading order form...</p>}>
        <OrderForm products={products} />
      </Suspense>
    </div>
  );
}
