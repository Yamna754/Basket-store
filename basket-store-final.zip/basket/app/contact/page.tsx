import type { Metadata } from "next";
import { Mail, Phone, MapPin } from "lucide-react";
import { ContactForm } from "@/components/ContactForm";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { SITE_SETTINGS } from "@/lib/config";
import { SocialIcons } from "@/components/SocialIcons";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with the BASKET team via email, phone or WhatsApp.",
};

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8 md:py-14">
      <div className="mb-10 text-center md:text-left">
        <h1 className="text-3xl font-bold text-navy-900 md:text-4xl">Contact Us</h1>
        <p className="mt-2 text-slate-500">We'd love to hear from you.</p>
      </div>

      <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
        <div className="space-y-6">
          <div className="flex items-start gap-4 rounded-xl2 border border-slate-100 p-5 shadow-card">
            <Mail className="mt-1 text-accent-600" size={22} />
            <div>
              <p className="font-semibold text-navy-900">Email</p>
              <p className="text-slate-500">{SITE_SETTINGS.contactEmail}</p>
            </div>
          </div>
          <div className="flex items-start gap-4 rounded-xl2 border border-slate-100 p-5 shadow-card">
            <Phone className="mt-1 text-accent-600" size={22} />
            <div>
              <p className="font-semibold text-navy-900">Phone</p>
              <p className="text-slate-500">{SITE_SETTINGS.contactPhone}</p>
            </div>
          </div>
          <div className="flex items-start gap-4 rounded-xl2 border border-slate-100 p-5 shadow-card">
            <MapPin className="mt-1 text-accent-600" size={22} />
            <div>
              <p className="font-semibold text-navy-900">Address</p>
              <p className="text-slate-500">{SITE_SETTINGS.contactAddress}</p>
            </div>
          </div>
          <div>
            <p className="mb-3 font-semibold text-navy-900">Follow &amp; reach us</p>
            <SocialIcons />
          </div>
          <WhatsAppButton
            message={`Hi ${SITE_SETTINGS.storeName}! I have a question.`}
            label="Chat on WhatsApp"
            className="w-full sm:w-auto"
          />
        </div>

        <ContactForm />
      </div>
    </div>
  );
}
