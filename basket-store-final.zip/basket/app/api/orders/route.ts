import { NextRequest, NextResponse } from "next/server";
import { createOrder, getAllOrders, validateOrderInput } from "@/lib/orders";
import type { NewOrderInput } from "@/types/order";

export async function GET() {
  const orders = await getAllOrders();
  return NextResponse.json({ orders });
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as Partial<NewOrderInput>;

  // Server-side validation — never trust the client, even though the
  // order form also validates in the browser.
  const errors = validateOrderInput(body);
  if (errors.length > 0) {
    return NextResponse.json({ errors }, { status: 400 });
  }

  const order = await createOrder(body as NewOrderInput);
  return NextResponse.json({ order }, { status: 201 });
}
