import { NextRequest, NextResponse } from "next/server";
import { getChatReply, type ChatMessage } from "@/lib/chatbot";

// Placeholder route for the future AI chatbot (see lib/chatbot/index.ts).
// Not wired into the UI yet — kept here so the structure exists.
export async function POST(req: NextRequest) {
  const body = (await req.json()) as { messages: ChatMessage[] };
  const reply = await getChatReply(body.messages ?? []);
  return NextResponse.json({ reply });
}
