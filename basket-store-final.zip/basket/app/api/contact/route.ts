import { NextRequest, NextResponse } from "next/server";

interface ContactPayload {
  name?: string;
  email?: string;
  phone?: string;
  message?: string;
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as ContactPayload;

  if (!body.name?.trim() || !body.email?.trim() || !body.message?.trim()) {
    return NextResponse.json(
      { error: "Name, email and message are required." },
      { status: 400 }
    );
  }

  // DEMO: just logs server-side. PRODUCTION: send an email (e.g. via
  // Resend/SendGrid) or insert into a Supabase "contact_messages" table.
  console.log("New contact message:", body);

  return NextResponse.json({ success: true });
}
