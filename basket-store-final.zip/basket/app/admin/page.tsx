import type { Metadata } from "next";
import { AdminLoginForm } from "@/components/AdminLoginForm";

export const metadata: Metadata = {
  title: "Admin Login",
  robots: { index: false, follow: false },
};

export default function AdminLoginPage() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-7xl items-center justify-center px-4 py-14 md:px-8">
      <div className="w-full max-w-sm rounded-xl2 border border-slate-100 p-8 shadow-card">
        <h1 className="mb-1 text-center text-2xl font-bold text-navy-900">Admin Login</h1>
        <p className="mb-6 text-center text-sm text-slate-500">BASKET Admin Dashboard</p>
        <AdminLoginForm />
      </div>
    </div>
  );
}
