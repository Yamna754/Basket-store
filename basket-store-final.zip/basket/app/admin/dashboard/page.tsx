import type { Metadata } from "next";
import { AdminTable } from "@/components/AdminTable";

export const metadata: Metadata = {
  title: "Admin Dashboard",
  robots: { index: false, follow: false },
};

export default function AdminDashboardPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14">
      <AdminTable />
    </div>
  );
}
