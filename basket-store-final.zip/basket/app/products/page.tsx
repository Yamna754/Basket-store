import type { Metadata } from "next";
import { getAllProducts, getAllCategories } from "@/lib/products";
import { ProductsPageClient } from "@/components/ProductsPageClient";

export const metadata: Metadata = {
  title: "Shop All Products",
  description: "Browse our full collection of racing-inspired jackets.",
};

export default async function ProductsPage() {
  const [products, categories] = await Promise.all([getAllProducts(), getAllCategories()]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl font-bold text-navy-900 md:text-4xl">Shop All Products</h1>
        <p className="mt-2 text-slate-500">
          {products.length} racing-inspired jackets, ready to ship nationwide.
        </p>
      </div>
      <ProductsPageClient products={products} categories={categories} />
    </div>
  );
}
