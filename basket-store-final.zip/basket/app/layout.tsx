import type { Metadata } from "next";
import { Inter, Sora } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingWhatsApp } from "@/components/SocialIcons";
import { CartProvider } from "@/context/CartContext";
import { SITE_SETTINGS, SITE_URL } from "@/lib/config";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const sora = Sora({ subsets: ["latin"], variable: "--font-sora" });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${SITE_SETTINGS.storeName} — ${SITE_SETTINGS.tagline}`,
    template: `%s | ${SITE_SETTINGS.storeName}`,
  },
  description: SITE_SETTINGS.heroSubheadline,
  openGraph: {
    title: `${SITE_SETTINGS.storeName} — ${SITE_SETTINGS.tagline}`,
    description: SITE_SETTINGS.heroSubheadline,
    siteName: SITE_SETTINGS.storeName,
    images: ["/images/hero-fashion.jpg"],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_SETTINGS.storeName} — ${SITE_SETTINGS.tagline}`,
    description: SITE_SETTINGS.heroSubheadline,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable}`}>
      <body className="flex min-h-screen flex-col font-sans">
        <CartProvider>
          <div className="bg-navy-900 px-4 py-2 text-center text-xs font-medium tracking-wide text-white md:text-sm">
            Bumper Offer: Kids jackets Rs. 2,999 &nbsp;·&nbsp; Buy 2 &amp; get 10% off &nbsp;·&nbsp; Cash on Delivery
          </div>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <FloatingWhatsApp />
        </CartProvider>
      </body>
    </html>
  );
}
