// Placeholder for future "customer accounts / login" feature.
// Keeping this as its own file means auth can be added later without
// touching the Order or Product types.

export interface Customer {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  whatsapp?: string;
  addresses: CustomerAddress[];
  createdAt: string;
}

export interface CustomerAddress {
  id: string;
  label: string; // "Home", "Office"...
  address: string;
  city: string;
  isDefault: boolean;
}
