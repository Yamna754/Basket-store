// Site-wide settings that the future admin dashboard should be able to
// edit (contact info, WhatsApp number, homepage banners, etc.) without
// a code deploy. For now these are read from lib/config.ts, but the
// shape is what a `site_settings` database table would look like.

export interface SiteSettings {
  storeName: string;
  whatsappNumber: string;
  contactEmail: string;
  contactPhone: string;
  contactAddress: string;
  heroHeadline: string;
  heroSubheadline: string;
}
