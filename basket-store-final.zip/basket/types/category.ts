import type { ProductCategory } from "./product";

export interface Category {
  id: string;
  slug: ProductCategory;
  label: string;
  description?: string;
}
