// Central type definitions for products.
// Any layer of the app (data, components, API routes) imports these
// so the shape of a "product" only ever needs to be defined once.

export interface ProductImage {
  url: string;
  alt: string;
}

export interface ProductVariantOption {
  /** e.g. "Black", "Navy", "Red" */
  name: string;
  /** optional hex code, used to render a color swatch */
  hex?: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  shortDescription: string;
  /** current selling price */
  price: number;
  /** original price, if the product is on sale — used to show a strikethrough */
  compareAtPrice?: number;
  images: ProductImage[];
  category: ProductCategory;
  colors: ProductVariantOption[];
  sizes: string[];
  /** units in stock — powers "Out of stock" state once inventory is wired up */
  stock: number;
  featured: boolean;
  /** soft-delete / hide-without-deleting flag */
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export type ProductCategory =
  | "racing-jackets"
  | "mens-jackets"
  | "womens-jackets"
  | "hoodies"
  | "t-shirts"
  | "accessories";

export interface ProductCategoryInfo {
  slug: ProductCategory;
  label: string;
}
