// Order & order-item types shared between the order form, the API route,
// and the admin dashboard.

export type OrderStatus =
  | "new"
  | "confirmed"
  | "processing"
  | "shipped"
  | "delivered"
  | "cancelled";

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  color: string;
  size: string;
  quantity: number;
  unitPrice: number;
}

export interface CustomerInfo {
  fullName: string;
  phone: string;
  whatsapp: string;
  address: string;
  city: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customer: CustomerInfo;
  items: OrderItem[];
  notes?: string;
  subtotal: number;
  discountAmount: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

/** Shape of the data the order form submits, before the server assigns
 * an id / orderNumber / timestamps. */
export type NewOrderInput = Omit<
  Order,
  "id" | "orderNumber" | "status" | "createdAt" | "updatedAt"
>;
