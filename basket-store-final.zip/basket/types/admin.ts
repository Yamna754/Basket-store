// Types for admin users and roles. A single `role` field today is enough
// for the demo, but the shape already supports "multiple admin roles"
// (requirement #29) without changing anything else.

export type AdminRole = "owner" | "manager" | "support";

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: AdminRole;
}

export interface AdminSession {
  user: AdminUser;
  token: string;
  expiresAt: string;
}
