import Image from "next/image";
import { Truck, BadgePercent, Sparkles } from "lucide-react";
import { Button } from "./ui/Button";
import { SITE_SETTINGS } from "@/lib/config";

const PERKS = [
  { icon: Sparkles, text: "Kids sizes 3–15 years" },
  { icon: BadgePercent, text: "Buy 2, get 10% off" },
  { icon: Truck, text: "Cash on Delivery" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-white">
      {/* soft decorative glow */}
      <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-sky-200/40 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 right-0 h-96 w-96 rounded-full bg-blue-200/30 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-4 py-14 md:grid-cols-2 md:px-8 md:py-24">
        <div className="text-center md:text-left">
          <span className="inline-block rounded-full border border-sky-200 bg-white px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-accent-600 shadow-sm">
            Bumper Offer · Kids Jackets Rs. 2,999
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-[1.1] tracking-tight text-navy-900 md:text-6xl">
            Race-Inspired Jackets,{" "}
            <span className="text-accent-600">
              Built For The Street
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-md text-base leading-relaxed text-slate-600 md:mx-0 md:text-lg">
            {SITE_SETTINGS.heroSubheadline}
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center md:justify-start">
            <Button href="/products" variant="primary" size="lg" className="shadow-lg shadow-navy-900/20">
              Shop Now
            </Button>
            <Button href="/order" variant="outline" size="lg" className="bg-white">
              Order Now
            </Button>
          </div>
          <ul className="mt-9 flex flex-wrap justify-center gap-x-6 gap-y-3 md:justify-start">
            {PERKS.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-2 text-sm font-medium text-slate-600">
                <Icon size={18} className="text-accent-600" />
                {text}
              </li>
            ))}
          </ul>
        </div>

        {/* Real product photo collage */}
        <div className="relative order-first mx-auto w-full max-w-xl md:order-last">
          <div className="grid grid-cols-2 gap-4">
            <div className="relative col-span-2 aspect-[5/4] overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-slate-200">
              <Image
                src="/images/redbull-racing-jacket.jpg"
                alt="Red Bull Racing kids jacket"
                fill
                priority
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="relative aspect-[5/4] overflow-hidden rounded-2xl bg-white shadow-lg ring-1 ring-slate-200">
              <Image
                src="/images/ferrari-pink-jacket.jpg"
                alt="Ferrari pink kids jacket"
                fill
                sizes="(max-width: 768px) 50vw, 25vw"
                className="object-cover"
              />
            </div>
            <div className="relative aspect-[5/4] overflow-hidden rounded-2xl bg-white shadow-lg ring-1 ring-slate-200">
              <Image
                src="/images/monster-kawasaki-jacket.jpg"
                alt="Monster Energy Kawasaki kids jacket"
                fill
                sizes="(max-width: 768px) 50vw, 25vw"
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
