import Link from "next/link";
import Image from "next/image";
import { Mail, Phone, MapPin } from "lucide-react";
import { NAV_LINKS, SITE_SETTINGS } from "@/lib/config";
import { SocialIcons } from "./SocialIcons";

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white text-slate-600">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-4 py-14 md:grid-cols-4 md:px-8">
        <div>
          <Image
            src="/images/logo.png"
            alt={`${SITE_SETTINGS.storeName} logo`}
            width={130}
            height={40}
            className="h-10 w-auto"
          />
          <p className="mt-4 text-sm leading-relaxed text-slate-500">{SITE_SETTINGS.tagline}</p>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wide text-navy-900">Explore</h4>
          <ul className="space-y-2 text-sm">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="hover:text-accent-600">
                  {link.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/order" className="hover:text-accent-600">
                Track / Place an Order
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wide text-navy-900">Contact</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2">
              <Mail size={16} className="mt-0.5 shrink-0 text-accent-600" />
              <span>{SITE_SETTINGS.contactEmail}</span>
            </li>
            <li className="flex items-start gap-2">
              <Phone size={16} className="mt-0.5 shrink-0 text-accent-600" />
              <span>{SITE_SETTINGS.contactPhone}</span>
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={16} className="mt-0.5 shrink-0 text-accent-600" />
              <span>{SITE_SETTINGS.contactAddress}</span>
            </li>
          </ul>
          <div className="mt-5">
            <SocialIcons />
          </div>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wide text-navy-900">Legal</h4>
          <p className="text-xs leading-relaxed text-slate-500">
            Some product designs reference third-party motorsport brands for stylistic
            inspiration only. {SITE_SETTINGS.storeName} is an independent store and is not
            affiliated with, sponsored by, or endorsed by those brands.
          </p>
        </div>
      </div>
      <div className="border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} {SITE_SETTINGS.storeName}. All rights reserved.
      </div>
    </footer>
  );
}
