import { Facebook, Instagram, Youtube, Phone, Mail } from "lucide-react";
import { CONTACT_LINKS_ENABLED, SOCIAL_LINKS } from "@/lib/config";

const WhatsAppIcon = ({ size = 20 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M20.5 3.5A11.9 11.9 0 0 0 12 0C5.4 0 .1 5.3.1 11.9c0 2.1.5 4.1 1.6 5.9L0 24l6.4-1.7a11.9 11.9 0 0 0 5.6 1.4c6.6 0 11.9-5.3 11.9-11.9 0-3.2-1.2-6.2-3.4-8.3ZM12 21.7c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.8 1 1-3.7-.2-.4a9.8 9.8 0 0 1-1.5-5.2C2.1 6.5 6.5 2.1 12 2.1c2.6 0 5.1 1 6.9 2.9a9.7 9.7 0 0 1 2.9 6.9c0 5.4-4.4 9.8-9.8 9.8Zm5.4-7.3c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1l-.9 1.1c-.2.2-.3.2-.6.1a8 8 0 0 1-4-3.5c-.3-.5.3-.5.9-1.6.1-.2 0-.4 0-.5l-.9-2.1c-.2-.5-.4-.4-.7-.4h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5 1.9.8 2.6.9 3.6.7.6-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.2-.6-.4Z" />
  </svg>
);

const TikTokIcon = ({ size = 20 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M19.6 6.7a5.4 5.4 0 0 1-3.3-1.9 5.4 5.4 0 0 1-1.2-3.1h-3.4v13.6a2.9 2.9 0 1 1-2-2.8V9.1a6.3 6.3 0 1 0 5.4 6.2V9a8.8 8.8 0 0 0 4.6 1.4V7a5.4 5.4 0 0 1-.1-.3Z" />
  </svg>
);

const ITEMS = [
  { key: "whatsapp", label: "WhatsApp", href: SOCIAL_LINKS.whatsapp, Icon: WhatsAppIcon, color: "hover:bg-[#25D366]" },
  { key: "facebook", label: "Facebook", href: SOCIAL_LINKS.facebook, Icon: Facebook, color: "hover:bg-[#1877F2]" },
  { key: "instagram", label: "Instagram", href: SOCIAL_LINKS.instagram, Icon: Instagram, color: "hover:bg-[#E4405F]" },
  { key: "tiktok", label: "TikTok", href: SOCIAL_LINKS.tiktok, Icon: TikTokIcon, color: "hover:bg-black" },
  { key: "youtube", label: "YouTube", href: SOCIAL_LINKS.youtube, Icon: Youtube, color: "hover:bg-[#FF0000]" },
  { key: "phone", label: "Call us", href: SOCIAL_LINKS.phone, Icon: Phone, color: "hover:bg-accent-600" },
  { key: "email", label: "Email", href: SOCIAL_LINKS.email, Icon: Mail, color: "hover:bg-accent-600" },
] as const;

/** Row of round icons. Clickable only when CONTACT_LINKS_ENABLED (lib/config.ts). */
export function SocialIcons({ dark = false }: { dark?: boolean }) {
  const base = `flex h-10 w-10 items-center justify-center rounded-full ${
    dark ? "bg-white/10 text-slate-200" : "bg-white text-navy-900 shadow-sm ring-1 ring-slate-200"
  }`;
  return (
    <ul className="flex flex-wrap gap-3">
      {ITEMS.map(({ key, label, href, Icon, color }) => (
        <li key={key}>
          {CONTACT_LINKS_ENABLED ? (
            <a
              href={href}
              target={href.startsWith("http") ? "_blank" : undefined}
              rel="noopener noreferrer"
              aria-label={label}
              title={label}
              className={`${base} transition-colors hover:text-white ${color}`}
            >
              <Icon size={20} />
            </a>
          ) : (
            <span aria-label={label} className={`${base} cursor-default select-none`}>
              <Icon size={20} />
            </span>
          )}
        </li>
      ))}
    </ul>
  );
}

/** Floating WhatsApp button, bottom-right on every page. */
export function FloatingWhatsApp() {
  const cls =
    "fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg";
  if (!CONTACT_LINKS_ENABLED) {
    return (
      <span aria-label="WhatsApp" className={`${cls} cursor-default select-none`}>
        <WhatsAppIcon size={30} />
      </span>
    );
  }
  return (
    <a
      href={SOCIAL_LINKS.whatsapp}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className={`${cls} transition-transform hover:scale-105`}
    >
      <WhatsAppIcon size={30} />
    </a>
  );
}
