import { Search, Palette, ClipboardList, PackageCheck } from "lucide-react";

const STEPS = [
  { icon: Search, title: "Browse Products", description: "Explore our racing jacket collection online." },
  { icon: Palette, title: "Choose Options", description: "Pick your color, size and quantity." },
  { icon: ClipboardList, title: "Submit Your Order", description: "Fill in your details and confirm the order." },
  { icon: PackageCheck, title: "Receive Your Order", description: "We prepare it and deliver it to your door." },
];

export function HowItWorks() {
  return (
    <section className="border-y border-slate-200 bg-white py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold text-navy-900 md:text-4xl">How It Works</h2>
          <p className="mt-3 text-slate-500">Ordering from BASKET takes less than two minutes.</p>
        </div>

        <div className="relative mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map(({ icon: Icon, title, description }, i) => (
            <div key={title} className="relative flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-accent-600 shadow-card ring-1 ring-sky-100">
                <Icon size={26} />
              </div>
              <span className="mt-3 text-xs font-bold uppercase tracking-wide text-accent-600">
                Step {i + 1}
              </span>
              <h3 className="mt-1 font-semibold text-navy-900">{title}</h3>
              <p className="mt-2 text-sm text-slate-500">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
