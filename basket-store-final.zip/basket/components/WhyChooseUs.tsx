import { ShieldCheck, Truck, Sparkles, Headphones } from "lucide-react";

const REASONS = [
  {
    icon: ShieldCheck,
    title: "Premium Quality",
    description: "Durable fabrics and reinforced stitching built to last season after season.",
  },
  {
    icon: Truck,
    title: "Nationwide Delivery",
    description: "Fast, tracked delivery to every major city, with Cash on Delivery available.",
  },
  {
    icon: Sparkles,
    title: "Exclusive Designs",
    description: "Limited-run motorsport-inspired styles you won't find in generic stores.",
  },
  {
    icon: Headphones,
    title: "Real Human Support",
    description: "Message us directly on WhatsApp — a real person replies, not a bot.",
  },
];

export function WhyChooseUs() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 md:px-8 md:py-24">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-bold text-navy-900 md:text-4xl">Why Choose BASKET</h2>
        <p className="mt-3 text-slate-500">
          Everything about the way we design, ship and support our jackets is built around you.
        </p>
      </div>

      <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {REASONS.map(({ icon: Icon, title, description }) => (
          <div key={title} className="rounded-xl2 border border-slate-100 p-6 text-center shadow-card">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-accent-500/10 text-accent-600">
              <Icon size={24} />
            </div>
            <h3 className="mt-4 font-semibold text-navy-900">{title}</h3>
            <p className="mt-2 text-sm text-slate-500">{description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
