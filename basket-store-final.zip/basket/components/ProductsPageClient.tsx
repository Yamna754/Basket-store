"use client";

import { useMemo, useState } from "react";
import { ProductsFilterBar } from "./ProductsFilterBar";
import { ProductGrid } from "./ProductGrid";
import type { Product, ProductCategory } from "@/types/product";
import type { Category } from "@/types/category";

export function ProductsPageClient({
  products,
  categories,
}: {
  products: Product[];
  categories: Category[];
}) {
  const [activeCategory, setActiveCategory] = useState<ProductCategory | "all">("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    let result = products;
    if (activeCategory !== "all") {
      result = result.filter((p) => p.category === activeCategory);
    }
    const q = query.trim().toLowerCase();
    if (q) {
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q)
      );
    }
    return result;
  }, [products, activeCategory, query]);

  return (
    <div>
      <ProductsFilterBar
        categories={categories}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
        query={query}
        onQueryChange={setQuery}
      />
      <div className="mt-8">
        <ProductGrid products={filtered} />
      </div>
    </div>
  );
}
