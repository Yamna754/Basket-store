"use client";

import { Search } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Category } from "@/types/category";
import type { ProductCategory } from "@/types/product";

export function ProductsFilterBar({
  categories,
  activeCategory,
  onCategoryChange,
  query,
  onQueryChange,
}: {
  categories: Category[];
  activeCategory: ProductCategory | "all";
  onCategoryChange: (c: ProductCategory | "all") => void;
  query: string;
  onQueryChange: (q: string) => void;
}) {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => onCategoryChange("all")}
          className={cn(
            "rounded-full px-4 py-2 text-sm font-medium transition-colors",
            activeCategory === "all"
              ? "bg-navy-900 text-white"
              : "bg-slate-100 text-navy-900 hover:bg-slate-200"
          )}
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat.slug}
            onClick={() => onCategoryChange(cat.slug)}
            className={cn(
              "rounded-full px-4 py-2 text-sm font-medium transition-colors",
              activeCategory === cat.slug
                ? "bg-navy-900 text-white"
                : "bg-slate-100 text-navy-900 hover:bg-slate-200"
            )}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <div className="relative w-full md:w-72">
        <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search products..."
          className="w-full rounded-full border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-sm focus:border-accent-500 focus:outline-none focus:ring-2 focus:ring-accent-500/20"
        />
      </div>
    </div>
  );
}
