"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, Download, LogOut } from "lucide-react";
import { Table, Th, Td } from "./ui/Table";
import { Badge } from "./ui/Badge";
import { Button } from "./ui/Button";
import { Modal } from "./ui/Modal";
import { Input } from "./ui/Input";
import { formatPrice } from "@/lib/utils";
import { useRouter } from "next/navigation";
import type { Order, OrderStatus } from "@/types/order";

const STATUSES: OrderStatus[] = ["new", "confirmed", "processing", "shipped", "delivered", "cancelled"];

export function AdminTable() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<OrderStatus | "all">("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const router = useRouter();

  async function loadOrders() {
    setLoading(true);
    try {
      const res = await fetch("/api/orders");
      const data = await res.json();
      setOrders(data.orders ?? []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadOrders();
  }, []);

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      const matchesStatus = statusFilter === "all" || o.status === statusFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        o.orderNumber.toLowerCase().includes(q) ||
        o.customer.fullName.toLowerCase().includes(q) ||
        o.customer.phone.toLowerCase().includes(q);
      return matchesStatus && matchesQuery;
    });
  }, [orders, query, statusFilter]);

  async function handleStatusChange(orderId: string, status: OrderStatus) {
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
    await fetch(`/api/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
  }

  function handleExportCsv() {
    const header = ["Order #", "Customer", "Phone", "City", "Total", "Status", "Date"];
    const rows = filtered.map((o) => [
      o.orderNumber,
      o.customer.fullName,
      o.customer.phone,
      o.customer.city,
      o.total.toString(),
      o.status,
      new Date(o.createdAt).toLocaleString(),
    ]);
    const csv = [header, ...rows].map((r) => r.map((cell) => `"${cell}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `basket-orders-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleLogout() {
    document.cookie = "basket_admin=; path=/; max-age=0";
    router.push("/admin");
  }

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Orders</h1>
          <p className="text-sm text-slate-500">{orders.length} total orders (demo data)</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExportCsv} variant="outline" size="sm">
            <Download size={16} />
            Export Orders
          </Button>
          <Button onClick={handleLogout} variant="ghost" size="sm">
            <LogOut size={16} />
            Log Out
          </Button>
        </div>
      </div>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by order #, name or phone..."
            className="pl-10"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as OrderStatus | "all")}
          className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-accent-500 focus:outline-none"
        >
          <option value="all">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s[0].toUpperCase() + s.slice(1)}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <p className="text-slate-500">Loading orders...</p>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl2 border border-dashed border-slate-200 py-16 text-center text-slate-500">
          No orders yet. Once customers submit the order form, they'll show up here.
        </div>
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Order #</Th>
              <Th>Customer</Th>
              <Th>City</Th>
              <Th>Total</Th>
              <Th>Status</Th>
              <Th>Date</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((order) => (
              <tr key={order.id}>
                <Td className="font-medium text-navy-900">{order.orderNumber}</Td>
                <Td>
                  <p className="font-medium text-navy-900">{order.customer.fullName}</p>
                  <p className="text-xs text-slate-500">{order.customer.phone}</p>
                </Td>
                <Td>{order.customer.city}</Td>
                <Td className="font-semibold text-navy-900">{formatPrice(order.total)}</Td>
                <Td>
                  <select
                    value={order.status}
                    onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                    className="rounded-full border-0 bg-transparent text-xs font-semibold focus:outline-none"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </Td>
                <Td>{new Date(order.createdAt).toLocaleDateString()}</Td>
                <Td>
                  <button
                    onClick={() => setSelectedOrder(order)}
                    className="text-sm font-medium text-accent-600 hover:underline"
                  >
                    View
                  </button>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      <Modal open={!!selectedOrder} onClose={() => setSelectedOrder(null)} title={selectedOrder?.orderNumber}>
        {selectedOrder && (
          <div className="space-y-4 text-sm">
            <div>
              <p className="font-semibold text-navy-900">Customer</p>
              <p className="text-slate-600">{selectedOrder.customer.fullName}</p>
              <p className="text-slate-600">{selectedOrder.customer.phone}</p>
              <p className="text-slate-600">
                {selectedOrder.customer.address}, {selectedOrder.customer.city}
              </p>
            </div>
            <div>
              <p className="font-semibold text-navy-900">Items</p>
              <ul className="mt-1 space-y-2">
                {selectedOrder.items.map((item, i) => (
                  <li key={i} className="flex justify-between text-slate-600">
                    <span>
                      {item.productName} ({item.color}/{item.size}) × {item.quantity}
                    </span>
                    <span>{formatPrice(item.unitPrice * item.quantity)}</span>
                  </li>
                ))}
              </ul>
            </div>
            {selectedOrder.notes && (
              <div>
                <p className="font-semibold text-navy-900">Notes</p>
                <p className="text-slate-600">{selectedOrder.notes}</p>
              </div>
            )}
            <div className="flex justify-between border-t border-slate-100 pt-3 font-semibold text-navy-900">
              <span>Total</span>
              <span>{formatPrice(selectedOrder.total)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={selectedOrder.status}>{selectedOrder.status}</Badge>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
