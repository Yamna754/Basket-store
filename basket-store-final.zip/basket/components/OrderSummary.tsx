import Image from "next/image";
import { calculateOrderTotals, formatPrice, MULTI_BUY_MIN_QTY } from "@/lib/utils";
import type { CartLine } from "@/context/CartContext";

export function OrderSummary({ lines }: { lines: CartLine[] }) {
  const { subtotal, discountAmount, discountApplied, total, itemCount } = calculateOrderTotals(
    lines.map((l) => ({ quantity: l.quantity, unitPrice: l.product.price }))
  );
  const itemsToUnlockDiscount = Math.max(0, MULTI_BUY_MIN_QTY - itemCount);

  return (
    <div className="rounded-xl2 border border-slate-100 p-5 md:p-6">
      <h3 className="mb-4 font-semibold text-navy-900">Order Summary</h3>

      {lines.length === 0 ? (
        <p className="text-sm text-slate-500">No products selected yet.</p>
      ) : (
        <ul className="space-y-4">
          {lines.map((line, i) => (
            <li key={`${line.product.id}-${line.color}-${line.size}-${i}`} className="flex gap-3">
              <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                <Image
                  src={line.product.images[0]?.url}
                  alt={line.product.name}
                  fill
                  sizes="56px"
                  className="object-cover"
                />
              </div>
              <div className="flex-1 text-sm">
                <p className="font-medium text-navy-900">{line.product.name}</p>
                <p className="text-slate-500">
                  {line.color} / {line.size} · Qty {line.quantity}
                </p>
              </div>
              <p className="text-sm font-semibold text-navy-900">
                {formatPrice(line.product.price * line.quantity)}
              </p>
            </li>
          ))}
        </ul>
      )}

      {lines.length > 0 && (
        <div className="mt-5 space-y-2 border-t border-slate-100 pt-4">
          <div className="flex items-center justify-between text-sm text-slate-500">
            <span>Subtotal</span>
            <span>{formatPrice(subtotal)}</span>
          </div>

          {discountApplied ? (
            <div className="flex items-center justify-between text-sm font-medium text-emerald-600">
              <span>Multi-buy discount (10%)</span>
              <span>− {formatPrice(discountAmount)}</span>
            </div>
          ) : (
            <p className="rounded-lg bg-sky-50 px-3 py-2 text-xs font-medium text-sky-700">
              Add {itemsToUnlockDiscount} more item{itemsToUnlockDiscount > 1 ? "s" : ""} to unlock
              10% off — buy 2 or more articles and save automatically.
            </p>
          )}

          <div className="flex items-center justify-between border-t border-slate-100 pt-3">
            <span className="font-semibold text-navy-900">Total</span>
            <span className="text-lg font-bold text-navy-900">{formatPrice(total)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
