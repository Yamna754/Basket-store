import { getFeaturedProducts } from "@/lib/products";
import { ProductGrid } from "./ProductGrid";
import { Button } from "./ui/Button";

export async function FeaturedProducts() {
  const products = await getFeaturedProducts();

  return (
    <section className="mx-auto max-w-7xl px-4 py-16 md:px-8 md:py-24">
      <div className="mb-10 flex flex-col items-center justify-between gap-4 text-center md:flex-row md:text-left">
        <div>
          <h2 className="text-3xl font-bold text-navy-900 md:text-4xl">Featured Products</h2>
          <p className="mt-2 text-slate-500">Our most popular racing jackets this season.</p>
        </div>
        <Button href="/products" variant="outline">
          View All Products
        </Button>
      </div>
      <ProductGrid products={products} />
    </section>
  );
}
