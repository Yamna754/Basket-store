import { WhatsAppButton } from "./WhatsAppButton";
import { SITE_SETTINGS } from "@/lib/config";

export function WhatsAppSection() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-16 md:px-8 md:pb-24">
      <div className="flex flex-col items-center justify-between gap-6 rounded-xl2 bg-[#25D366]/10 p-8 text-center md:flex-row md:p-12 md:text-left">
        <div>
          <h3 className="text-2xl font-bold text-navy-900">Prefer to Order on WhatsApp?</h3>
          <p className="mt-2 max-w-md text-slate-600">
            Chat with us directly — ask questions, confirm sizes, and place your order in seconds.
          </p>
        </div>
        <WhatsAppButton
          message={`Hi ${SITE_SETTINGS.storeName}! I'd like to place an order.`}
          label="Chat on WhatsApp"
          size="lg"
        />
      </div>
    </section>
  );
}
