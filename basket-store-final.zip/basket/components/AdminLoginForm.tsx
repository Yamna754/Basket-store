"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "./ui/Button";
import { Input, Label } from "./ui/Input";
import { loginAdmin, DEMO_ADMIN_EMAIL, DEMO_ADMIN_PASSWORD } from "@/lib/auth";

export function AdminLoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (loginAdmin(email, password)) {
      // DEMO ONLY: a plain, unsigned cookie. See lib/auth.ts for the
      // production warning — this must be replaced with real session
      // management before going live.
      document.cookie = "basket_admin=1; path=/; max-age=86400";
      router.push("/admin/dashboard");
    } else {
      setError("Invalid email or password.");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto w-full max-w-sm space-y-4">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="password">Password</Label>
        <Input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <Button type="submit" className="w-full">
        Log In
      </Button>
      <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
        Demo credentials — email: <code className="font-mono">{DEMO_ADMIN_EMAIL}</code>, password:{" "}
        <code className="font-mono">{DEMO_ADMIN_PASSWORD}</code>
      </p>
    </form>
  );
}
