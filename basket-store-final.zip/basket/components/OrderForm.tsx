"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import { Minus, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { Button } from "./ui/Button";
import { Input, Label, Textarea } from "./ui/Input";
import { OrderSummary } from "./OrderSummary";
import { WhatsAppButton } from "./WhatsAppButton";
import { useCart } from "@/context/CartContext";
import { calculateOrderTotals, formatPrice } from "@/lib/utils";
import { SITE_SETTINGS } from "@/lib/config";
import type { Product } from "@/types/product";
import type { Order } from "@/types/order";

export function OrderForm({ products }: { products: Product[] }) {
  const searchParams = useSearchParams();
  const { lines, addToCart, removeFromCart, updateQuantity, clearCart } = useCart();

  // Support arriving via /order?product=slug (from a ProductCard's "Order Now")
  // by pre-adding that product if the cart doesn't already have items.
  const [prefillHandled, setPrefillHandled] = useState(false);
  useEffect(() => {
    if (prefillHandled) return;
    const slug = searchParams.get("product");
    if (slug && lines.length === 0) {
      const product = products.find((p) => p.slug === slug);
      if (product) {
        addToCart({
          product,
          color: product.colors[0]?.name ?? "",
          size: product.sizes[0] ?? "",
          quantity: 1,
        });
      }
    }
    setPrefillHandled(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefillHandled]);

  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id ?? "");
  const selectedProduct = products.find((p) => p.id === selectedProductId);
  const [color, setColor] = useState(selectedProduct?.colors[0]?.name ?? "");
  const [size, setSize] = useState(selectedProduct?.sizes[0] ?? "");
  const [quantity, setQuantity] = useState(1);

  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    whatsapp: "",
    address: "",
    city: "",
    notes: "",
  });

  const [errors, setErrors] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);

  const { subtotal, discountAmount, discountApplied, total } = useMemo(
    () =>
      calculateOrderTotals(lines.map((l) => ({ quantity: l.quantity, unitPrice: l.product.price }))),
    [lines]
  );

  function handleAddSelectedProduct() {
    if (!selectedProduct) return;
    addToCart({ product: selectedProduct, color, size, quantity });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrors([]);

    const items = lines.map((l) => ({
      productId: l.product.id,
      productName: l.product.name,
      productImage: l.product.images[0]?.url ?? "",
      color: l.color,
      size: l.size,
      quantity: l.quantity,
      unitPrice: l.product.price,
    }));

    const payload = {
      customer: {
        fullName: form.fullName,
        phone: form.phone,
        whatsapp: form.whatsapp || form.phone,
        address: form.address,
        city: form.city,
      },
      items,
      notes: form.notes,
      subtotal,
      discountAmount,
      total,
    };

    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrors(data.errors ?? ["Something went wrong. Please try again."]);
        return;
      }
      setSuccessOrder(data.order);
      clearCart();
    } catch {
      setErrors(["Network error — please check your connection and try again."]);
    } finally {
      setSubmitting(false);
    }
  }

  if (successOrder) {
    const waMessage = [
      `Hi ${SITE_SETTINGS.storeName}, I just placed order ${successOrder.orderNumber}.`,
      `Name: ${successOrder.customer.fullName}`,
      successOrder.discountAmount > 0
        ? `Total: ${formatPrice(successOrder.total)} (10% multi-buy discount applied)`
        : `Total: ${formatPrice(successOrder.total)}`,
      `Payment: Cash on Delivery`,
    ].join("\n");

    return (
      <div className="mx-auto max-w-lg rounded-xl2 border border-slate-100 p-8 text-center shadow-card">
        <CheckCircle2 className="mx-auto text-emerald-500" size={56} />
        <h2 className="mt-4 text-2xl font-bold text-navy-900">
          Your order has been submitted successfully.
        </h2>
        <p className="mt-2 text-slate-500">
          Order number: <span className="font-semibold text-navy-900">{successOrder.orderNumber}</span>
        </p>
        <p className="mt-1 text-sm text-slate-500">
          We'll contact you on WhatsApp/phone shortly to confirm delivery details.
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <WhatsAppButton message={waMessage} label="Confirm on WhatsApp" />
          <Button href="/products" variant="outline">
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1.4fr_1fr]">
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Product selector — lets someone build an order from scratch */}
        <div className="rounded-xl2 border border-slate-100 p-5 md:p-6">
          <h3 className="mb-4 font-semibold text-navy-900">Add a Product</h3>
          {products.length === 0 ? (
            <p className="text-sm text-slate-500">No products available.</p>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="product-select">Product</Label>
                  <select
                    id="product-select"
                    value={selectedProductId}
                    onChange={(e) => {
                      const p = products.find((pr) => pr.id === e.target.value);
                      setSelectedProductId(e.target.value);
                      setColor(p?.colors[0]?.name ?? "");
                      setSize(p?.sizes[0] ?? "");
                    }}
                    className="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-accent-500 focus:outline-none focus:ring-2 focus:ring-accent-500/20"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} — {formatPrice(p.price)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="color-select">Color</Label>
                  <select
                    id="color-select"
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-accent-500 focus:outline-none focus:ring-2 focus:ring-accent-500/20"
                  >
                    {selectedProduct?.colors.map((c) => (
                      <option key={c.name} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="size-select">Size</Label>
                  <select
                    id="size-select"
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-accent-500 focus:outline-none focus:ring-2 focus:ring-accent-500/20"
                  >
                    {selectedProduct?.sizes.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label>Quantity</Label>
                  <div className="inline-flex items-center rounded-lg border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="flex h-11 w-11 items-center justify-center text-navy-900 hover:bg-slate-50"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="w-10 text-center font-semibold">{quantity}</span>
                    <button
                      type="button"
                      onClick={() => setQuantity((q) => q + 1)}
                      className="flex h-11 w-11 items-center justify-center text-navy-900 hover:bg-slate-50"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              </div>

              <Button type="button" onClick={handleAddSelectedProduct} variant="secondary" className="mt-4">
                Add to Order
              </Button>
            </>
          )}
        </div>

        {/* Selected lines */}
        {lines.length > 0 && (
          <div className="rounded-xl2 border border-slate-100 p-5 md:p-6">
            <h3 className="mb-4 font-semibold text-navy-900">Products in This Order</h3>
            <ul className="space-y-4">
              {lines.map((line, i) => (
                <li key={`${line.product.id}-${line.color}-${line.size}-${i}`} className="flex items-center gap-3">
                  <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                    <Image src={line.product.images[0]?.url} alt={line.product.name} fill sizes="56px" className="object-cover" />
                  </div>
                  <div className="flex-1 text-sm">
                    <p className="font-medium text-navy-900">{line.product.name}</p>
                    <p className="text-slate-500">
                      {line.color} / {line.size}
                    </p>
                  </div>
                  <div className="inline-flex items-center rounded-lg border border-slate-200">
                    <button
                      type="button"
                      onClick={() => updateQuantity(i, line.quantity - 1)}
                      className="flex h-9 w-9 items-center justify-center text-navy-900 hover:bg-slate-50"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-8 text-center text-sm font-semibold">{line.quantity}</span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(i, line.quantity + 1)}
                      className="flex h-9 w-9 items-center justify-center text-navy-900 hover:bg-slate-50"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeFromCart(i)}
                    className="text-slate-400 hover:text-red-500"
                    aria-label="Remove item"
                  >
                    <Trash2 size={18} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Customer info */}
        <div className="rounded-xl2 border border-slate-100 p-5 md:p-6">
          <h3 className="mb-4 font-semibold text-navy-900">Your Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                required
                value={form.fullName}
                onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))}
                placeholder="Ali Khan"
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                required
                type="tel"
                value={form.phone}
                onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                placeholder="03001234567"
              />
            </div>
            <div>
              <Label htmlFor="whatsapp">WhatsApp Number</Label>
              <Input
                id="whatsapp"
                type="tel"
                value={form.whatsapp}
                onChange={(e) => setForm((f) => ({ ...f, whatsapp: e.target.value }))}
                placeholder="Same as phone, if left blank"
              />
            </div>
            <div>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                required
                value={form.city}
                onChange={(e) => setForm((f) => ({ ...f, city: e.target.value }))}
                placeholder="Karachi"
              />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="address">Complete Address</Label>
              <Textarea
                id="address"
                required
                value={form.address}
                onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
                placeholder="House #, Street, Area, City"
              />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="notes">Additional Notes (optional)</Label>
              <Textarea
                id="notes"
                value={form.notes}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                placeholder="Delivery instructions, gift wrap, etc."
              />
            </div>
          </div>
        </div>

        {errors.length > 0 && (
          <div className="rounded-xl2 border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <ul className="list-inside list-disc space-y-1">
              {errors.map((err) => (
                <li key={err}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="rounded-xl2 border border-slate-100 bg-slate-50 p-4 text-sm text-slate-600">
          <p className="font-medium text-navy-900">Payment: Cash on Delivery</p>
          <p className="mt-1">Pay in cash when your order arrives at your doorstep.</p>
          {discountApplied && (
            <p className="mt-2 font-medium text-emerald-600">
              10% multi-buy discount applied — you saved {formatPrice(discountAmount)}!
            </p>
          )}
        </div>

        <Button type="submit" size="lg" disabled={submitting} className="w-full sm:w-auto">
          {submitting ? "Submitting..." : "Submit Order"}
        </Button>
      </form>

      <div>
        <div className="sticky top-24">
          <OrderSummary lines={lines} />
        </div>
      </div>
    </div>
  );
}
