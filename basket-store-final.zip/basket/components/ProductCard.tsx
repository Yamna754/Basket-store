import Image from "next/image";
import Link from "next/link";
import { Card } from "./ui/Card";
import { Button } from "./ui/Button";
import { formatPrice } from "@/lib/utils";
import type { Product } from "@/types/product";

/** The single card used everywhere a product is listed (Home,
 * Products grid, Related products). Add a product in
 * lib/data/products.data.ts and it will automatically render here —
 * this component never needs to change. */
export function ProductCard({ product }: { product: Product }) {
  const onSale = product.compareAtPrice && product.compareAtPrice > product.price;

  return (
    <Card hover className="group flex flex-col overflow-hidden">
      <Link href={`/products/${product.slug}`} className="relative block aspect-[4/5] overflow-hidden bg-slate-50">
        <Image
          src={product.images[0]?.url}
          alt={product.images[0]?.alt ?? product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover object-top transition-transform duration-500 group-hover:scale-105"
        />
        {onSale && (
          <span className="absolute left-3 top-3 rounded-full bg-red-500 px-3 py-1 text-xs font-semibold text-white">
            Sale
          </span>
        )}
        {product.stock === 0 && (
          <span className="absolute right-3 top-3 rounded-full bg-navy-900 px-3 py-1 text-xs font-semibold text-white">
            Out of stock
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-4 md:p-5">
        <Link href={`/products/${product.slug}`}>
          <h3 className="font-semibold text-navy-900 transition-colors hover:text-accent-600">
            {product.name}
          </h3>
        </Link>
        <p className="mt-1 line-clamp-2 text-sm text-slate-500">{product.shortDescription}</p>

        <div className="mt-3 flex items-center gap-2">
          <span className="text-lg font-bold text-navy-900">{formatPrice(product.price)}</span>
          {onSale && (
            <span className="text-sm text-slate-400 line-through">
              {formatPrice(product.compareAtPrice!)}
            </span>
          )}
        </div>

        <div className="mt-4 flex gap-2">
          <Button href={`/products/${product.slug}`} variant="outline" size="sm" className="flex-1">
            View Details
          </Button>
          <Button href={`/order?product=${product.slug}`} variant="primary" size="sm" className="flex-1">
            Order Now
          </Button>
        </div>
      </div>
    </Card>
  );
}
