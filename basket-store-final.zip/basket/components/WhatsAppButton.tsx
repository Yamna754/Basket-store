import { MessageCircle } from "lucide-react";
import { Button } from "./ui/Button";
import { buildWhatsAppLink } from "@/lib/utils";
import { CONTACT_LINKS_ENABLED } from "@/lib/config";

/** Every WhatsApp CTA in the app renders through this component, so the
 * message format and the phone number (lib/config.ts) only need to be
 * right in one place. */
export function WhatsAppButton({
  message,
  label = "Chat on WhatsApp",
  variant = "whatsapp",
  size = "md",
  className,
}: {
  message: string;
  label?: string;
  variant?: "whatsapp" | "outline";
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  if (!CONTACT_LINKS_ENABLED) {
    // Demo lock: looks identical, but is not clickable.
    return (
      <Button type="button" variant={variant} size={size} className={`pointer-events-none ${className ?? ""}`}>
        <MessageCircle size={18} />
        {label}
      </Button>
    );
  }
  return (
    <Button
      href={buildWhatsAppLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      variant={variant}
      size={size}
      className={className}
    >
      <MessageCircle size={18} />
      {label}
    </Button>
  );
}
