import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Card({
  children,
  className,
  hover = false,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-xl2 border border-slate-200/70 bg-white shadow-card",
        hover && "transition-shadow duration-300 hover:shadow-cardHover",
        className
      )}
    >
      {children}
    </div>
  );
}
