"use client";

import { useState } from "react";
import Image from "next/image";
import { Minus, Plus, ShoppingBag } from "lucide-react";
import { Button } from "./ui/Button";
import { WhatsAppButton } from "./WhatsAppButton";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/utils";
import { SITE_SETTINGS } from "@/lib/config";
import type { Product } from "@/types/product";
import { useRouter } from "next/navigation";

export function ProductDetails({ product }: { product: Product }) {
  const [activeImage, setActiveImage] = useState(0);
  const [color, setColor] = useState(product.colors[0]?.name ?? "");
  const [size, setSize] = useState(product.sizes[0] ?? "");
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const router = useRouter();

  const outOfStock = product.stock === 0;

  const whatsappMessage = [
    `Hi ${SITE_SETTINGS.storeName}! I'd like to order:`,
    `Product: ${product.name}`,
    `Color: ${color}`,
    `Size: ${size}`,
    `Quantity: ${quantity}`,
    `Total: ${formatPrice(product.price * quantity)}`,
  ].join("\n");

  function handleAddToCart() {
    addToCart({ product, color, size, quantity });
  }

  function handleOrderNow() {
    addToCart({ product, color, size, quantity });
    router.push("/order");
  }

  return (
    <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
      {/* Gallery */}
      <div>
        <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xl2 bg-slate-100">
          <Image
            src={product.images[activeImage]?.url}
            alt={product.images[activeImage]?.alt ?? product.name}
            fill
            priority
            sizes="(max-width: 768px) 100vw, 50vw"
            className="object-cover object-top"
          />
        </div>
        {product.images.length > 1 && (
          <div className="mt-3 flex gap-3">
            {product.images.map((img, i) => (
              <button
                key={img.url}
                onClick={() => setActiveImage(i)}
                className={`relative h-20 w-16 overflow-hidden rounded-lg border-2 ${
                  i === activeImage ? "border-accent-500" : "border-transparent"
                }`}
              >
                <Image src={img.url} alt={img.alt} fill sizes="80px" className="object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Info */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-accent-600">
          {product.category.replace("-", " ")}
        </p>
        <h1 className="mt-2 text-3xl font-bold text-navy-900 md:text-4xl">{product.name}</h1>

        <div className="mt-4 flex items-center gap-3">
          <span className="text-2xl font-bold text-navy-900">{formatPrice(product.price)}</span>
          {product.compareAtPrice && (
            <span className="text-lg text-slate-400 line-through">
              {formatPrice(product.compareAtPrice)}
            </span>
          )}
        </div>

        <p className="mt-4 leading-relaxed text-slate-600">{product.description}</p>

        {/* Color */}
        <div className="mt-6">
          <p className="mb-2 text-sm font-semibold text-navy-900">
            Color: <span className="font-normal text-slate-500">{color}</span>
          </p>
          <div className="flex gap-2">
            {product.colors.map((c) => (
              <button
                key={c.name}
                onClick={() => setColor(c.name)}
                title={c.name}
                className={`h-9 w-9 rounded-full border-2 transition-transform ${
                  color === c.name ? "scale-110 border-accent-500" : "border-slate-200"
                }`}
                style={{ backgroundColor: c.hex ?? "#ccc" }}
              />
            ))}
          </div>
        </div>

        {/* Size */}
        <div className="mt-6">
          <p className="mb-2 text-sm font-semibold text-navy-900">Size</p>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((s) => (
              <button
                key={s}
                onClick={() => setSize(s)}
                className={`min-w-[3rem] rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                  size === s
                    ? "border-navy-900 bg-navy-900 text-white"
                    : "border-slate-200 text-navy-900 hover:border-navy-900"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Quantity */}
        <div className="mt-6">
          <p className="mb-2 text-sm font-semibold text-navy-900">Quantity</p>
          <div className="inline-flex items-center rounded-lg border border-slate-200">
            <button
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              className="flex h-11 w-11 items-center justify-center text-navy-900 hover:bg-slate-50"
              aria-label="Decrease quantity"
            >
              <Minus size={16} />
            </button>
            <span className="w-10 text-center font-semibold">{quantity}</span>
            <button
              onClick={() => setQuantity((q) => q + 1)}
              className="flex h-11 w-11 items-center justify-center text-navy-900 hover:bg-slate-50"
              aria-label="Increase quantity"
            >
              <Plus size={16} />
            </button>
          </div>
        </div>

        {outOfStock && (
          <p className="mt-4 text-sm font-semibold text-red-600">
            This product is currently out of stock.
          </p>
        )}

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button onClick={handleAddToCart} variant="outline" disabled={outOfStock} className="flex-1">
            <ShoppingBag size={18} />
            Add to Cart
          </Button>
          <Button onClick={handleOrderNow} variant="primary" disabled={outOfStock} className="flex-1">
            Order Now
          </Button>
        </div>
        <div className="mt-3">
          <WhatsAppButton message={whatsappMessage} label="Order on WhatsApp" className="w-full sm:w-auto" />
        </div>

        <div className="mt-8 rounded-xl2 border border-slate-100 p-5 text-sm text-slate-600">
          <p className="font-semibold text-navy-900">Product Information</p>
          <ul className="mt-2 list-inside list-disc space-y-1">
            <li>Cash on Delivery available nationwide</li>
            <li>Ships within 2-4 business days</li>
            <li>Easy exchange within 3 days of delivery</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
