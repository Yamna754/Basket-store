import { getRelatedProducts } from "@/lib/products";
import { ProductGrid } from "./ProductGrid";
import type { Product } from "@/types/product";

export async function RelatedProducts({ product }: { product: Product }) {
  const related = await getRelatedProducts(product);
  if (related.length === 0) return null;

  return (
    <section className="mt-20">
      <h2 className="text-2xl font-bold text-navy-900">You Might Also Like</h2>
      <div className="mt-6">
        <ProductGrid products={related} />
      </div>
    </section>
  );
}
