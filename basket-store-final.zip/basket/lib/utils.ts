import { SITE_SETTINGS } from "./config";

/** clsx-lite: merge class name strings, skipping falsy values. */
export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export function formatPrice(amount: number): string {
  return `${SITE_SETTINGS.currencySymbol} ${amount.toLocaleString("en-PK")}`;
}

/** BSK-2026-0001 style human-friendly order numbers */
export function generateOrderNumber(): string {
  const year = new Date().getFullYear();
  const random = Math.floor(1000 + Math.random() * 9000);
  return `BSK-${year}-${random}`;
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

// ------------------------------------------------------------
// Order totals + multi-buy discount
// ------------------------------------------------------------
// Store-wide rule: buy 2 or more articles (total quantity across the
// order, not distinct products) in one order and get 10% off the
// subtotal. Kept in one place so the cart, the order summary, the
// order form and the server-side order API all agree on the number.
export const MULTI_BUY_MIN_QTY = 2;
export const MULTI_BUY_DISCOUNT_RATE = 0.1; // 10%

export interface OrderTotals {
  itemCount: number;
  subtotal: number;
  discountRate: number;
  discountAmount: number;
  total: number;
  discountApplied: boolean;
}

export function calculateOrderTotals(
  items: { quantity: number; unitPrice: number }[]
): OrderTotals {
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);
  const subtotal = items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0);
  const discountApplied = itemCount >= MULTI_BUY_MIN_QTY;
  const discountRate = discountApplied ? MULTI_BUY_DISCOUNT_RATE : 0;
  const discountAmount = Math.round(subtotal * discountRate);
  const total = subtotal - discountAmount;
  return { itemCount, subtotal, discountRate, discountAmount, total, discountApplied };
}

/** Builds a wa.me link with a pre-filled message. Every WhatsApp button
 * in the app should go through this helper so the number only ever
 * lives in one place (lib/config.ts). */
export function buildWhatsAppLink(message: string, number = SITE_SETTINGS.whatsappNumber): string {
  const digits = number.replace(/[^0-9]/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}
