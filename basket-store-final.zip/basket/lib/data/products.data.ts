// ============================================================
// RAW PRODUCT RECORDS (DEMO DATA)
// ------------------------------------------------------------
// This file is the "database" in demo mode. Add a new product by
// adding a new object to this array — nothing else needs to change:
// the Products page, Home page, ProductCard and Product Details page
// all read from lib/products.ts, which reads from here.
//
// In production mode, lib/products.ts swaps this file out for
// Supabase queries (see lib/supabase/products.ts) — the rest of the
// app is unaffected because it only ever imports from lib/products.ts.
//
// IMAGES: place real product photos in /public/images/ and point
// each product's `images` array at the file name, e.g. "/images/my-photo.jpg".
//
// SIZES: all real product photos supplied are kids' racing jackets,
// so sizes below use ages 3 to 15. Update if adult sizing is
// also needed.
// ============================================================

import type { Product } from "@/types/product";

const KIDS_SIZES = Array.from({ length: 13 }, (_, i) => `${i + 3}Y`); // ages 3 to 15
export const MENS_SIZES = ["S", "M", "L", "XL"];
export const KIDS_PRICE = 2999; // bumper offer
export const MENS_PRICE = 5999;

export const PRODUCTS: Product[] = [
  {
    id: "1",
    slug: "red-bull-racing-jacket",
    name: "Red Bull Racing Jacket",
    shortDescription: "Bold black racing jacket with Red Bull, Infiniti and Pepe Jeans graphics.",
    description:
      "Channel the energy of the pit lane with this Red Bull Racing-inspired jacket. Full-zip front, ribbed cuffs, contrast blue shoulder piping, and bold embroidered team graphics on the chest, back and sleeves — built for kids who love motorsport.",
    price: KIDS_PRICE,
    images: [{ url: "/images/redbull-racing-jacket.jpg", alt: "Red Bull Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Black", hex: "#0f0f0f" }],
    sizes: KIDS_SIZES,
    stock: 24,
    featured: true,
    active: true,
    createdAt: "2026-01-10T00:00:00.000Z",
    updatedAt: "2026-01-10T00:00:00.000Z",
  },
  {
    id: "2",
    slug: "monster-energy-jacket",
    name: "Monster Energy Jacket",
    shortDescription: "Black-and-green NASCAR Cup Series style jacket with Monster Energy branding.",
    description:
      "A street-ready jacket inspired by Monster Energy's iconic claw logo and NASCAR Cup Series styling. Rugged black shell with contrast green piping, snap-button front, and sponsor patches across the chest and sleeves.",
    price: KIDS_PRICE,
    images: [{ url: "/images/monster-energy-jacket.jpg", alt: "Monster Energy Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Black", hex: "#0f0f0f" }],
    sizes: KIDS_SIZES,
    stock: 18,
    featured: true,
    active: true,
    createdAt: "2026-01-12T00:00:00.000Z",
    updatedAt: "2026-01-12T00:00:00.000Z",
  },
  {
    id: "3",
    slug: "ferrari-pink-racing-jacket",
    name: "Ferrari Pink Racing Jacket",
    shortDescription: "Limited-edition pink Ferrari-style racing jacket with Scuderia patches.",
    description:
      "A bold twist on classic motorsport style — this limited pink racing jacket pairs Ferrari-inspired detailing with the prancing horse emblem on the back and sponsor patches on the chest and sleeves. Lightweight and finished with a contrast white panel.",
    price: KIDS_PRICE,
    images: [{ url: "/images/ferrari-pink-jacket.jpg", alt: "Ferrari Pink Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Pink", hex: "#ec4899" }],
    sizes: KIDS_SIZES,
    stock: 12,
    featured: true,
    active: true,
    createdAt: "2026-01-14T00:00:00.000Z",
    updatedAt: "2026-01-14T00:00:00.000Z",
  },
  {
    id: "4",
    slug: "mclaren-mercedes-jacket",
    name: "McLaren Mercedes-Benz Jacket",
    shortDescription: "Sleek black jacket with McLaren and Mercedes-Benz team branding.",
    description:
      "A premium black racing jacket featuring the McLaren wordmark and Mercedes-Benz star across the chest and back, with subtle piping detail on the shoulders and matching sponsor text on both sleeves.",
    price: KIDS_PRICE,
    images: [{ url: "/images/mclaren-benz-boss-jacket.jpg", alt: "McLaren Mercedes-Benz Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Black", hex: "#0f0f0f" }],
    sizes: KIDS_SIZES,
    stock: 15,
    featured: true,
    active: true,
    createdAt: "2026-01-16T00:00:00.000Z",
    updatedAt: "2026-01-16T00:00:00.000Z",
  },
  {
    id: "5",
    slug: "marlboro-racing-jacket",
    name: "Marlboro Racing Jacket",
    shortDescription: "Retro cream-and-red racing jacket with classic Marlboro motorsport styling.",
    description:
      "A retro-inspired racing jacket in cream and red, with a bold \"RACING\" print across the back, sponsor patches on the chest, and ribbed contrast cuffs and hem for a classic motorsport look.",
    price: KIDS_PRICE,
    images: [{ url: "/images/marlboro-racing-jacket.jpg", alt: "Marlboro Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Cream/Red", hex: "#e7ddc8" }],
    sizes: KIDS_SIZES,
    stock: 14,
    featured: false,
    active: true,
    createdAt: "2026-01-18T00:00:00.000Z",
    updatedAt: "2026-01-18T00:00:00.000Z",
  },
  {
    id: "6",
    slug: "ferrari-grey-racing-jacket",
    name: "Ferrari Grey Racing Jacket",
    shortDescription: "Grey-and-black Ferrari-style jacket with Bridgestone and Michelin patches.",
    description:
      "A modern grey-and-black racing jacket with the Ferrari shield on the chest and back, contrast black sleeves and collar, and sponsor patches for an authentic garage-team look.",
    price: KIDS_PRICE,
    images: [{ url: "/images/ferrari-grey-jacket.jpg", alt: "Ferrari Grey Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Grey/Black", hex: "#4b5563" }],
    sizes: KIDS_SIZES,
    stock: 16,
    featured: false,
    active: true,
    createdAt: "2026-01-20T00:00:00.000Z",
    updatedAt: "2026-01-20T00:00:00.000Z",
  },
  {
    id: "7",
    slug: "bmw-racing-jacket",
    name: "BMW Racing Jacket",
    shortDescription: "Crisp white BMW Racing jacket with Castrol sleeve patch.",
    description:
      "A clean white racing jacket with the BMW roundel on the chest and back, bold blue \"RACING\" text down both sleeves, and a Castrol sponsor patch for an authentic team look.",
    price: KIDS_PRICE,
    images: [{ url: "/images/bmw-racing-jacket.jpg", alt: "BMW Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "White", hex: "#f8fafc" }],
    sizes: KIDS_SIZES,
    stock: 20,
    featured: false,
    active: true,
    createdAt: "2026-01-22T00:00:00.000Z",
    updatedAt: "2026-01-22T00:00:00.000Z",
  },
  {
    id: "8",
    slug: "monster-kawasaki-jacket",
    name: "Monster Energy Kawasaki Jacket",
    shortDescription: "Black-and-green Kawasaki jacket with Monster Energy claw logo.",
    description:
      "A vibrant black-and-green jacket combining the Kawasaki wordmark on the sleeves with the Monster Energy claw logo on the chest and back — a bold pick for motocross and racing fans alike.",
    price: KIDS_PRICE,
    images: [{ url: "/images/monster-kawasaki-jacket.jpg", alt: "Monster Energy Kawasaki Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Black/Green", hex: "#16a34a" }],
    sizes: KIDS_SIZES,
    stock: 17,
    featured: false,
    active: true,
    createdAt: "2026-01-24T00:00:00.000Z",
    updatedAt: "2026-01-24T00:00:00.000Z",
  },
  {
    id: "9",
    slug: "mclaren-vodafone-jacket",
    name: "McLaren Vodafone Racing Jacket",
    shortDescription: "Classic black, white and grey McLaren jacket with Vodafone and Santander branding.",
    description:
      "A classic three-tone racing jacket in black, white and grey, featuring the McLaren and Mercedes-Benz marks on the back, and Vodafone, Santander and Mobil 1 sponsor branding across the front and sleeves.",
    price: KIDS_PRICE,
    images: [{ url: "/images/mclaren-vodafone-jacket.jpg", alt: "McLaren Vodafone Racing Jacket - front and back" }],
    category: "racing-jackets",
    colors: [{ name: "Black/White/Grey", hex: "#0a1428" }],
    sizes: KIDS_SIZES,
    stock: 13,
    featured: false,
    active: true,
    createdAt: "2026-01-26T00:00:00.000Z",
    updatedAt: "2026-01-26T00:00:00.000Z",
  },
  {
    id: "10",
    slug: "mens-lamborghini-jacket",
    name: "Lamborghini Black & Gold Jacket",
    shortDescription: "Black bomber-style jacket with gold Lamborghini embroidery.",
    description:
      "A sleek black racing jacket with gold embroidered Lamborghini lettering on the chest and script down both sleeves, gold shoulder piping, a stand-up collar and ribbed cuffs and hem.",
    price: MENS_PRICE,
    images: [{ url: "/images/mens-lamborghini-jacket.jpg", alt: "Lamborghini Black & Gold Jacket" }],
    category: "mens-jackets",
    colors: [{ name: "Black/Gold", hex: "#111111" }],
    sizes: MENS_SIZES,
    stock: 15,
    featured: false,
    active: true,
    createdAt: "2026-02-01T00:00:00.000Z",
    updatedAt: "2026-02-01T00:00:00.000Z",
  },
  {
    id: "11",
    slug: "mens-lexus-jacket",
    name: "Lexus Navy Racing Jacket",
    shortDescription: "Clean navy jacket with white Lexus branding and shoulder piping.",
    description:
      "A refined navy racing jacket with white Lexus logos on the chest and sleeve, white piping across the shoulders, a full-zip front and ribbed cuffs — smart enough for the office, sporty enough for the weekend.",
    price: MENS_PRICE,
    images: [{ url: "/images/mens-lexus-jacket.jpg", alt: "Lexus Navy Racing Jacket" }],
    category: "mens-jackets",
    colors: [{ name: "Navy", hex: "#0a1428" }],
    sizes: MENS_SIZES,
    stock: 15,
    featured: false,
    active: true,
    createdAt: "2026-02-02T00:00:00.000Z",
    updatedAt: "2026-02-02T00:00:00.000Z",
  },
  {
    id: "12",
    slug: "mens-lakers-jacket",
    name: "Lakers Blue & Yellow Bomber",
    shortDescription: "Blue and gold bomber jacket with a bold chest logo.",
    description:
      "A vibrant blue-and-yellow bomber jacket with a large team logo on the chest, contrast yellow shoulders, a black ribbed collar, cuffs and hem, and a smooth full-zip front.",
    price: MENS_PRICE,
    images: [{ url: "/images/mens-lakers-jacket.jpg", alt: "Lakers Blue & Yellow Bomber" }],
    category: "mens-jackets",
    colors: [{ name: "Blue/Yellow", hex: "#1d4ed8" }],
    sizes: MENS_SIZES,
    stock: 15,
    featured: false,
    active: true,
    createdAt: "2026-02-03T00:00:00.000Z",
    updatedAt: "2026-02-03T00:00:00.000Z",
  },
  {
    id: "13",
    slug: "mens-bmw-petronas-jacket",
    name: "BMW M Power Petronas Jacket",
    shortDescription: "White racing jacket with BMW M Power and Petronas panel.",
    description:
      "A crisp white racing jacket with a grey chest panel, BMW and M Power badges, bold RACING text down the sleeves and black ribbed cuffs and hem.",
    price: MENS_PRICE,
    images: [{ url: "/images/mens-bmw-petronas-jacket.jpg", alt: "BMW M Power Petronas Jacket" }],
    category: "mens-jackets",
    colors: [{ name: "White/Grey", hex: "#f1f5f9" }],
    sizes: MENS_SIZES,
    stock: 15,
    featured: false,
    active: true,
    createdAt: "2026-02-04T00:00:00.000Z",
    updatedAt: "2026-02-04T00:00:00.000Z",
  },
  {
    id: "14",
    slug: "adult-ferrari-pink-jacket",
    name: "Ferrari Pink Racing Jacket (Adult)",
    shortDescription: "Pink Ferrari-style racing jacket in adult sizes.",
    description:
      "The popular pink Ferrari-style racing jacket in adult sizes, with Scuderia patch, Shell and UPS badges, a white chest panel and sleeve patches.",
    price: MENS_PRICE,
    images: [{ url: "/images/adult-ferrari-pink-jacket.jpg", alt: "Ferrari Pink Racing Jacket (Adult)" }],
    category: "womens-jackets",
    colors: [{ name: "Pink", hex: "#f9a8d4" }],
    sizes: MENS_SIZES,
    stock: 12,
    featured: false,
    active: true,
    createdAt: "2026-02-05T00:00:00.000Z",
    updatedAt: "2026-02-05T00:00:00.000Z",
  },
];
