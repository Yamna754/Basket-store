import type { Category } from "@/types/category";

export const CATEGORIES: Category[] = [
  { id: "1", slug: "racing-jackets", label: "Racing Jackets", description: "Motorsport-inspired jackets" },
  { id: "5", slug: "mens-jackets", label: "Men's Jackets", description: "Racing jackets for men (S–XL)" },
  { id: "6", slug: "womens-jackets", label: "Women's Jackets", description: "Racing jackets for women (S–XL)" },
  { id: "2", slug: "hoodies", label: "Hoodies", description: "Casual everyday hoodies" },
  { id: "3", slug: "t-shirts", label: "T-Shirts", description: "Graphic and plain tees" },
  { id: "4", slug: "accessories", label: "Accessories", description: "Caps, bags and more" },
];
