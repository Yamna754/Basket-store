// ============================================================
// SUPABASE — BROWSER CLIENT
// ------------------------------------------------------------
// Safe to import from client components. Only ever uses the
// public URL + anon key (protected by Row Level Security on the
// Supabase side) — never the service-role key.
//
// This file is inert in demo mode: it only does something once
// NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY are set
// and NEXT_PUBLIC_APP_MODE=production.
// ============================================================

import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const supabaseBrowser =
  supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null;
