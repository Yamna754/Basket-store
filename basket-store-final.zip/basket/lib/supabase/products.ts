// ============================================================
// SUPABASE — PRODUCT QUERIES (production mode)
// ------------------------------------------------------------
// These functions have the exact same signatures as the demo
// functions in lib/products.ts. Once you're ready to go live:
//   1. Run the SQL in supabase/schema.sql against your project.
//   2. Fill in the Supabase env vars in .env.local.
//   3. In lib/products.ts, swap each function body for the
//      matching one below.
// No component needs to change.
// ============================================================

import { supabaseAdmin } from "./server";
import type { Product } from "@/types/product";

export async function supabaseGetAllProducts(): Promise<Product[]> {
  if (!supabaseAdmin) throw new Error("Supabase is not configured.");
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("active", true)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Product[];
}

export async function supabaseGetProductBySlug(slug: string): Promise<Product | null> {
  if (!supabaseAdmin) throw new Error("Supabase is not configured.");
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("slug", slug)
    .single();
  if (error) return null;
  return data as unknown as Product;
}
