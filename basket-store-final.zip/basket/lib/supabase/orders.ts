// ============================================================
// SUPABASE — ORDER QUERIES (production mode)
// ------------------------------------------------------------
// Mirrors lib/orders.ts. Swap the demo implementation for these
// once Supabase is connected — see /supabase/schema.sql.
// ============================================================

import { supabaseAdmin } from "./server";
import type { NewOrderInput, Order, OrderStatus } from "@/types/order";
import { generateOrderNumber } from "../utils";

export async function supabaseCreateOrder(input: NewOrderInput): Promise<Order> {
  if (!supabaseAdmin) throw new Error("Supabase is not configured.");
  const orderNumber = generateOrderNumber();
  const { data, error } = await supabaseAdmin
    .from("orders")
    .insert({
      order_number: orderNumber,
      customer: input.customer,
      items: input.items,
      notes: input.notes,
      total: input.total,
      status: "new",
    })
    .select()
    .single();
  if (error) throw error;
  return data as unknown as Order;
}

export async function supabaseGetAllOrders(): Promise<Order[]> {
  if (!supabaseAdmin) throw new Error("Supabase is not configured.");
  const { data, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Order[];
}

export async function supabaseUpdateOrderStatus(id: string, status: OrderStatus): Promise<void> {
  if (!supabaseAdmin) throw new Error("Supabase is not configured.");
  const { error } = await supabaseAdmin.from("orders").update({ status }).eq("id", id);
  if (error) throw error;
}
