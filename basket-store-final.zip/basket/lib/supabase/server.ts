// ============================================================
// SUPABASE — SERVER-ONLY CLIENT
// ------------------------------------------------------------
// Uses the service-role key, which bypasses Row Level Security.
// This file must NEVER be imported from a client component ("use
// client") — only from Server Components, Route Handlers
// (app/api/**/route.ts) or Server Actions.
//
// The service-role key must only ever live in this file, read from
// an environment variable that is NOT prefixed with NEXT_PUBLIC_,
// which keeps Next.js from ever bundling it into browser JS.
// ============================================================

import "server-only";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const supabaseAdmin =
  supabaseUrl && serviceRoleKey
    ? createClient(supabaseUrl, serviceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false },
      })
    : null;
