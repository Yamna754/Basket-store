// ============================================================
// PRODUCT DATA LAYER (public API)
// ------------------------------------------------------------
// Every part of the UI (Home, Products page, Product Details,
// ProductCard, admin dashboard) imports product data ONLY from
// this file — never directly from lib/data/products.data.ts.
//
// That indirection is what makes it possible to switch from demo
// mock data to a real Supabase database later by editing just the
// functions below, with zero changes to any component.
// ============================================================

import { PRODUCTS } from "./data/products.data";
import { CATEGORIES } from "./data/categories.data";
import { IS_DEMO_MODE } from "./config";
import type { Product, ProductCategory } from "@/types/product";

// When production mode + Supabase is connected, these functions would
// instead call the matching functions in lib/supabase/products.ts.
// e.g.:
//   export async function getAllProducts() {
//     if (IS_DEMO_MODE) return PRODUCTS.filter((p) => p.active);
//     return await supabaseGetAllProducts();
//   }

export async function getAllProducts(): Promise<Product[]> {
  return PRODUCTS.filter((p) => p.active);
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter((p) => p.featured);
}

export async function getProductBySlug(slug: string): Promise<Product | undefined> {
  const all = await getAllProducts();
  return all.find((p) => p.slug === slug);
}

export async function getProductsByCategory(category: ProductCategory): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter((p) => p.category === category);
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter((p) => p.id !== product.id && p.category === product.category).slice(0, limit);
}

export async function searchProducts(query: string): Promise<Product[]> {
  const all = await getAllProducts();
  const q = query.trim().toLowerCase();
  if (!q) return all;
  return all.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.shortDescription.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
  );
}

export function getAllCategories() {
  return CATEGORIES;
}

export { IS_DEMO_MODE };
