// ============================================================
// ADMIN AUTHENTICATION (DEMO)
// ------------------------------------------------------------
// DEMO MODE: a hard-coded demo password check + a signed-looking
// token stored in an httpOnly-style cookie via document.cookie
// (client-side, so NOT secure — see the warning below).
//
// THIS IS NOT PRODUCTION-SAFE AUTHENTICATION. It exists only so you
// can click around the admin dashboard. Before putting this site
// live with real orders, connect Supabase Auth (or another real
// auth provider) — see /supabase/schema.sql and the README section
// "Connecting Supabase" for the exact steps. Once connected, swap
// the body of `loginAdmin` below for a real supabase.auth.signInWithPassword
// call, and protect /admin/dashboard with real session checks in
// middleware.ts instead of the demo cookie flag.
// ============================================================

export const DEMO_ADMIN_EMAIL = "admin@basket-store.com";
export const DEMO_ADMIN_PASSWORD = "basket-demo-2026";

export function loginAdmin(email: string, password: string): boolean {
  return email.trim().toLowerCase() === DEMO_ADMIN_EMAIL && password === DEMO_ADMIN_PASSWORD;
}
