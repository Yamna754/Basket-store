// ============================================================
// ORDER DATA LAYER
// ------------------------------------------------------------
// Business logic for creating/reading/updating orders lives here,
// separate from the API route (app/api/orders/route.ts) and separate
// from the UI (components/OrderForm.tsx, admin dashboard).
//
// DEMO MODE: orders are kept in-memory on the server (this file's
// module scope) which is enough to demo the full flow, and the admin
// dashboard also mirrors them into the browser's localStorage so the
// dashboard can be refreshed without losing demo orders.
//
// PRODUCTION MODE: swap the bodies of these functions for calls into
// lib/supabase/orders.ts (Supabase insert/select/update). Because the
// API route and the admin dashboard only call these functions, no
// other file needs to change when you connect Supabase.
// ============================================================

import type { NewOrderInput, Order, OrderStatus } from "@/types/order";
import { calculateOrderTotals, generateOrderNumber } from "./utils";

// NOTE: this in-memory array resets whenever the server restarts.
// It exists purely so the demo has *something* server-side to show;
// the admin dashboard's source of truth in demo mode is localStorage
// (see components/AdminTable.tsx), which survives page refreshes.
const DEMO_ORDERS: Order[] = [];

export async function createOrder(input: NewOrderInput): Promise<Order> {
  const now = new Date().toISOString();

  // Never trust subtotal/discount/total sent from the browser — recompute
  // from the line items server-side. This is also the one place the
  // "buy 2+ articles, get 10% off" rule is enforced for real.
  const { subtotal, discountAmount, total } = calculateOrderTotals(
    input.items.map((i) => ({ quantity: i.quantity, unitPrice: i.unitPrice }))
  );

  const order: Order = {
    ...input,
    subtotal,
    discountAmount,
    total,
    id: crypto.randomUUID(),
    orderNumber: generateOrderNumber(),
    status: "new",
    createdAt: now,
    updatedAt: now,
  };

  // PRODUCTION: await supabaseInsertOrder(order)
  DEMO_ORDERS.unshift(order);
  return order;
}

export async function getAllOrders(): Promise<Order[]> {
  // PRODUCTION: return await supabaseGetAllOrders()
  return DEMO_ORDERS;
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<void> {
  const order = DEMO_ORDERS.find((o) => o.id === id);
  if (order) {
    order.status = status;
    order.updatedAt = new Date().toISOString();
  }
  // PRODUCTION: await supabaseUpdateOrderStatus(id, status)
}

/** Basic server-side validation. The order form also validates in the
 * browser, but that can always be bypassed, so we never trust it —
 * this is the real gate before an order is created. */
export function validateOrderInput(input: Partial<NewOrderInput>): string[] {
  const errors: string[] = [];
  if (!input.customer?.fullName?.trim()) errors.push("Full name is required.");
  if (!input.customer?.phone?.trim()) errors.push("Phone number is required.");
  if (!input.customer?.address?.trim()) errors.push("Address is required.");
  if (!input.customer?.city?.trim()) errors.push("City is required.");
  if (!input.items || input.items.length === 0) errors.push("At least one product is required.");
  input.items?.forEach((item, i) => {
    if (!item.color) errors.push(`Please choose a color for item ${i + 1}.`);
    if (!item.size) errors.push(`Please choose a size for item ${i + 1}.`);
    if (!item.quantity || item.quantity < 1) errors.push(`Quantity for item ${i + 1} must be at least 1.`);
  });
  return errors;
}
