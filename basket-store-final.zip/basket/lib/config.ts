// ============================================================
// CENTRAL CONFIGURATION FILE
// ------------------------------------------------------------
// Every value the store owner is likely to change lives here,
// read from environment variables with safe fallbacks so the
// app still runs if .env.local hasn't been set up yet (demo mode).
//
// Change your WhatsApp number, email, phone, address etc. by
// editing .env.local — NOT by hunting through components.
// ============================================================

export const APP_MODE: "demo" | "production" =
  (process.env.NEXT_PUBLIC_APP_MODE as "demo" | "production") || "demo";

export const IS_DEMO_MODE = APP_MODE === "demo";

/** Single source of truth for the WhatsApp number.
 *  Used by every "Order on WhatsApp" / "Chat on WhatsApp" button. */
export const WHATSAPP_NUMBER =
  process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "923001234567";

export const SITE_SETTINGS = {
  storeName: "BASKET",
  tagline: "Premium Racing & Motorsport Jackets",
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "hello@basket-store.com",
  contactPhone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "+92 300 1234567",
  contactAddress:
    process.env.NEXT_PUBLIC_CONTACT_ADDRESS ||
    "Shop 12, Fashion Plaza, Karachi, Pakistan",
  whatsappNumber: WHATSAPP_NUMBER,
  heroHeadline: "Race-Inspired Jackets, Built For The Street",
  heroSubheadline:
    "Premium motorsport-inspired jackets for kids and men — bold team designs, soft comfortable fabric, delivered to your door.",
  currency: "PKR",
  currencySymbol: "Rs.",
} as const;

export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
  { href: "/contact", label: "Contact Us" },
] as const;

// ------------------------------------------------------------
// SOCIAL & CONTACT LINKS  (edit ONLY here or in .env.local)
// Replace the "#" placeholders with the real page links later.
// Every icon on the site (footer, contact page, floating
// WhatsApp button) reads from this one object.
// ------------------------------------------------------------
// DEMO LOCK: while false, all contact / social / WhatsApp icons are
// visible but NOT clickable (used while showing the site to the client
// before final handover). To activate them after handover, set
// NEXT_PUBLIC_CONTACT_LINKS_ENABLED=true in .env.local (or change the
// fallback below to true).
export const CONTACT_LINKS_ENABLED =
  process.env.NEXT_PUBLIC_CONTACT_LINKS_ENABLED === "true";

export const SOCIAL_LINKS = {
  whatsapp: `https://wa.me/${WHATSAPP_NUMBER}`,
  facebook: process.env.NEXT_PUBLIC_FACEBOOK_URL || "#",
  instagram: process.env.NEXT_PUBLIC_INSTAGRAM_URL || "#",
  tiktok: process.env.NEXT_PUBLIC_TIKTOK_URL || "#",
  youtube: process.env.NEXT_PUBLIC_YOUTUBE_URL || "#",
  phone: `tel:${SITE_SETTINGS.contactPhone.replace(/[^+\d]/g, "")}`,
  email: `mailto:${SITE_SETTINGS.contactEmail}`,
} as const;
