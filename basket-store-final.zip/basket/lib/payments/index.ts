// ============================================================
// PAYMENT ABSTRACTION LAYER
// ------------------------------------------------------------
// The checkout / order form never talks to a payment provider
// directly — it only calls the functions exported here. That means
// adding Bank Transfer, a local Pakistani gateway (e.g. JazzCash,
// EasyPaisa) or an international gateway (Stripe) later is a matter
// of adding a new file in this folder + registering it below,
// with no changes to OrderForm.tsx or the order API route.
// ============================================================

export type PaymentMethodId = "cod" | "bank_transfer" | "card";

export interface PaymentMethod {
  id: PaymentMethodId;
  label: string;
  description: string;
  /** Whether this method is currently offered to customers. */
  enabled: boolean;
}

export interface PaymentResult {
  success: boolean;
  reference?: string;
  error?: string;
}

export interface PaymentProvider {
  method: PaymentMethodId;
  charge(amount: number, orderId: string): Promise<PaymentResult>;
}

// --- Cash on Delivery: the only method enabled today ---
const codProvider: PaymentProvider = {
  method: "cod",
  async charge(amount, orderId) {
    // No external call needed — payment happens on delivery.
    return { success: true, reference: `COD-${orderId}` };
  },
};

// Future providers get added here, e.g.:
// const jazzCashProvider: PaymentProvider = { method: "card", charge: ... };

const PROVIDERS: Record<PaymentMethodId, PaymentProvider | null> = {
  cod: codProvider,
  bank_transfer: null, // not implemented yet
  card: null, // not implemented yet
};

export const AVAILABLE_PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: "cod",
    label: "Cash on Delivery",
    description: "Pay in cash when your order arrives.",
    enabled: true,
  },
  {
    id: "bank_transfer",
    label: "Bank Transfer",
    description: "Coming soon.",
    enabled: false,
  },
  {
    id: "card",
    label: "Card / Online Payment",
    description: "Coming soon.",
    enabled: false,
  },
];

export async function chargePayment(
  method: PaymentMethodId,
  amount: number,
  orderId: string
): Promise<PaymentResult> {
  const provider = PROVIDERS[method];
  if (!provider) {
    return { success: false, error: `Payment method "${method}" is not available yet.` };
  }
  return provider.charge(amount, orderId);
}
