// ============================================================
// CHATBOT — STRUCTURE ONLY (not built yet)
// ------------------------------------------------------------
// This module intentionally does nothing yet. It exists so that:
//   - components/chatbot/  (UI)
//   - lib/chatbot/          (this file — logic / API client)
//   - app/api/chat/         (server route)
// are all wired together and ready. To turn this into a real AI
// chatbot later: implement `getChatReply` to call your AI provider
// (e.g. the Anthropic API) from app/api/chat/route.ts, and render
// the conversation in components/chatbot/ChatWidget.tsx.
// ============================================================

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export async function getChatReply(_messages: ChatMessage[]): Promise<string> {
  return "Live chat isn't connected yet — please use WhatsApp or the contact form for now!";
}
